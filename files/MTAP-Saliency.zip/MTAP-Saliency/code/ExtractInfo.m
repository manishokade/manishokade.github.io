% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% extract some information from encoded bitstream including DCT and
% motion information which consists of MVs and block coding modes

disp('Starting ExtractInfo')

if ~ispc && ~isunix
    error('The OS is not recognized')
end

SetEnvConst

for seq_dir=1:1
    if seq_dir == 1
        SEQ_DIR = SFU_DIR;
    else
        SEQ_DIR = DIEM_DIR;
    end
    
    SEQs = MyDir(SEQ_DIR);

    % define encoder types
    FORMATS = cell(size(QPs));
    % define extensions for encoder
    EXTS = cell(size(QPs));
    for i=1:numel(QPs)
        FORMATS{i} = ['H264_QP' num2str(QPs(i))];
        EXTS{i} = '264';
    end

    formatIndexs = 1:numel(FORMATS);
    for formatIndex=formatIndexs
        FORMAT = char(FORMATS(formatIndex));
        disp(FORMAT)
        EXT = char(EXTS(formatIndex));
        QP = QPs(formatIndex);

        for seqIndex = 1:numel(SEQs)
            SEQ_NAME = char(SEQs(seqIndex));
            disp('----------------');
            disp(SEQ_NAME)
            disp('----------------');
            ENCODER_DIR = [SEQ_DIR SEQ_NAME filesep FORMAT filesep];
            if flagEncode && exist(ENCODER_DIR,'dir')
                rmdir(ENCODER_DIR,'s')
            end

            if ~exist(ENCODER_DIR,'dir')
                mkdir(ENCODER_DIR);
            end

            [OUT_VDO,IN_VDO,~,~,~,~,~,~,IMG_W,IMG_H,~,~] = ...
                ParseInput(SEQ_DIR,FORMAT,SEQ_NAME);

            if flagEncode && ~copyfile(IN_VDO,OUT_VDO)
                error(['The program cannot copy ' IN_VDO ' into ' pwd])
            end

            currentFolder = pwd;
            cd(ENCODER_DIR)

            % flags options:
            % qprd: use rate distortion optimization for qp selection
            % mv4: use four motion vector by macroblock (mpeg4)
            % qpel: use 1/4 pel motion compensation

            % RDO options
            % 'cmp integer (encoding,video)'
            %     Set full pel me compare function.
            % 'subcmp integer (encoding,video)'
            %     Set sub pel me compare function.
            % 'mbcmp integer (encoding,video)'
            %     Set macroblock compare function.
            % 'precmp integer (encoding,video)'
            %     Set pre motion estimation compare function.
            % 'mbd integer (encoding,video)'
            %     Set macroblock decision algorithm (high quality mode).
            % 'skipcmp integer (encoding,video)'
            %     Set frame skip compare function.

            if flagEncode && strcmp(EXT,'264')
                if system([ffmpeg_o_run '-s ' num2str(IMG_W) 'x' num2str(IMG_H) ...
                        ' -r 30 -i seq.yuv -c:v libx264 -profile:v baseline' ...
                        ' -qmin ' num2str(QP) ' -qmax ' num2str(QP) ...
                        ' -flags +qpel -flags +mv4 '...
                        ' -r 30 -f rawvideo -y seq.' EXT])
                    %  ' -cmp rd -subcmp rd -mbcmp rd -precmp rd -mbd rd -skipcmp rd' ...
                    % ' -g 1000 -keyint_min 1000 ' ... % force GOP to 1000
                    error('Fatal error by ffmpeg')
                end
            end

            % decode encoded video sequence and extract bitstream information
            if system([ffmpeg_run '-i seq.' EXT ' -y seq.yuv'])
                error('Fatal error by ffmpeg')
            end
            if  exist('error.txt','file')
                error('error: Not written for this setup')
            end

            % delete the raw sequence to save space, but the downside
            % is that you have to create it if you need to access the
            % pixel data (such as using pixel-based methods)
            delete('seq.yuv')

            delete('motionbits_*.txt') % not used in this study

            fid_ = fopen('types.txt');
            a = fscanf(fid_,'%s');
            fclose(fid_);
            if ~isempty(strfind(a,'B'))
                error('not written for B-frame')
            end

            cd(currentFolder)
        end
    end
end
fprintf('\nExtract encoded information done!\n')
