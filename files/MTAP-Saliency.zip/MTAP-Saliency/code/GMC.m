% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% global motion compensation based on perspective transformation
% 
% Input
%     mv_x: (matrix) x-component of motion vecters
%     mv_y: (matrix) y-component of motion vecters
%     blkType: (matrix) block types
%     mask: (matrix) detected labelling mask of object
%     flag8p: (flag value) whether use 8-parameter transformation or 
%        6-parameter transformation
%     
% Output
%     mv_x_new: (matrix) x-component of motion vecters after compensating
%        global motion
%     mv_y_new: (matrix) y-component of motion vecters after compensating
%        global motion
%     gmp: global motion parameters corresponding to 6 or 8-parameter
%        transformation

function [gmc_mv_x,gmc_mv_y,gmp,w] = GMC(mv_x, mv_y, flag8p)

% define constants
BLK_SIZE = 4; % smallest block size in H.264
GMC_CONVRG = .001;
GMC_MAX_ITR = 20;
CUTOFF_STD_COEF = 2;
USE_ALL_BLK_PERC = .1;
STOP_BLK_PERC = .5;

[BLK_H,BLK_W] = size(mv_x);
N = BLK_H*BLK_W;
v_x = reshape(mv_x,N,1); v_y = reshape(mv_y,N,1);

% center coordinates in image size
x = reshape(mod(0:N-1,BLK_H)*BLK_SIZE+BLK_SIZE/2,N,1);
y = reshape(mod(0:N-1,BLK_W)*BLK_SIZE+BLK_SIZE/2,BLK_W,BLK_H);
y = reshape(y',N,1);

V = zeros(2*N,1);
V(1:2:end) = v_x + x; V(2:2:end) = v_y + y;

if ~flag8p
    H = zeros(2*N,6);
    H(1:2:end,1) = 1; H(1:2:end,2) = x; H(1:2:end,3) = y;
    H(2:2:end,4) = 1; H(2:2:end,5) = x; H(2:2:end,6) = y;
else
    H = zeros(2*N,8);
    H(1:2:end,1) = x; H(1:2:end,2) = y; H(1:2:end,3) = 1;
    H(2:2:end,4) = x; H(2:2:end,5) = y; H(2:2:end,6) = 1;
    H(1:2:end,7) = -x.*V(1:2:end); H(1:2:end,8) = -y.*V(1:2:end);
    H(2:2:end,7) = -x.*V(2:2:end); H(2:2:end,8) = -y.*V(2:2:end);
end

% initial wights
w = ones(N,1);
w_2 = ones(2*N,1);

% if there is not enough blocks to estimate GME then use all blocks
if sum(w~=0) < BLK_H*BLK_W*USE_ALL_BLK_PERC
    w = ones(N,1);
end

old_m_e = 0;
HtW = zeros(8,2*N);

for count=1:GMC_MAX_ITR % limit the number of iterations     
    w_2(1:2:end) = w; w_2(2:2:end) = w;

    if ~flag8p
        for i=1:6
            HtW(i,:) = H(:,i).*w_2;
        end
    else
        for i=1:8
            HtW(i,:) = H(:,i).*w_2;
        end
    end
    gmp = (HtW*H)\(HtW*V);
    
    if ~flag8p
        x_new = gmp(1)+gmp(2)*x+gmp(3)*y-x;
        y_new = gmp(4)+gmp(5)*x+gmp(6)*y-y;
    else
        c = gmp(7)*x+gmp(8)*y+1;
        x_new = (gmp(1)*x+gmp(2)*y+gmp(3))./c-x;
        y_new = (gmp(4)*x+gmp(5)*y+gmp(6))./c-y;
    end
    
    e = abs(v_x-x_new) + abs(v_y-y_new);
    % discard those blocks which we ignored it before
    e(w==0) = 1000;
    % only use those blocks which might have background motion
    eNonzero = e(w~=0); % estimation error with non-zero weighting factors
    m_e = mean(eNonzero);
    if abs(m_e - old_m_e) < GMC_CONVRG || max(eNonzero) < GMC_CONVRG
        break
    end
    old_m_e = m_e;
    
    c_m_e = m_e+CUTOFF_STD_COEF*std(eNonzero);
    
    w = (1-((e./c_m_e).^2)).^2;
    w(e > c_m_e) = 0;
    
    % if there is not enough blocks to estimate GME stop iterative 
    % estimation
    if sum(w~=0) < BLK_H*BLK_W*STOP_BLK_PERC
        break
    end
end

if ~flag8p
    v_x_new = gmp(1)+gmp(2)*x+gmp(3)*y-x;
    v_y_new = gmp(4)+gmp(5)*x+gmp(6)*y-y;
else
    c = gmp(7)*x+gmp(8)*y+1;
    v_x_new = (gmp(1)*x+gmp(2)*y+gmp(3))./c-x;
    v_y_new = (gmp(4)*x+gmp(5)*y+gmp(6))./c-y;
end

gmc_mv_x = v_x - v_x_new;
gmc_mv_x = reshape(gmc_mv_x,BLK_H,BLK_W);
gmc_mv_y = v_y - v_y_new;
gmc_mv_y = reshape(gmc_mv_y,BLK_H,BLK_W);

w = reshape(w~=0,BLK_H,BLK_W);