% checked
% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% get fixations of a sequence as a 3-D discrete map
%
% Input
%     SEQ_DIR: (string) root directory
%     SEQ_NAME: (string) input sequence
%     IMG_H: (integer value) number of horizontal pixels (height)
%     IMG_W: (integer value) number of vertical pixels (width)
%
% Output
%     fixMap1: (3-D matrix) fixation map of the right eye
%     fixMap2: (3-D matrix) fixation map of the left eye

function [fixMap1,fixMap2] = GetFixationsDIEM(SEQ_DIR,SEQ_NAME,IMG_H,IMG_W)

load([SEQ_DIR SEQ_NAME filesep 'fixations.mat'])

[~,~,SUBJ_CNT,FRMS_CNT] = size(fixations);

% create a map of fixations
fixMap1 = zeros(IMG_H,IMG_W,FRMS_CNT);
fixMap2 = zeros(IMG_H,IMG_W,FRMS_CNT);
for frame=1:FRMS_CNT 
    for i=1:SUBJ_CNT % right eye
        x = fixations(1,1,i,frame);
        y = fixations(2,1,i,frame);
        if x > 0 && y > 0
            fixMap1(x,y,frame) = fixMap1(x,y,frame)+1;
        end
    end
    for i=1:SUBJ_CNT % left eye
        x = fixations(1,2,i,frame);
        y = fixations(2,2,i,frame);
        if x > 0 && y > 0
            fixMap2(x,y,frame) = fixMap2(x,y,frame)+1;
        end
    end
end
