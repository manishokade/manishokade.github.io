function [sals,mask] = ICM(sals,L,ONE_DEGREE_MBLKS, T_t, T_o, T_c)

MAX_ITR = 8;

if nargin < 4
    T_t=1;
    T_o=1;
    T_c=1;
end

% spatial weight
W_sp = fspecial('gauss',3,ONE_DEGREE_MBLKS*2);
W_s = W_sp/W_sp(2,2); W_s = repmat(W_s,[1 1 L]);
% temporal weight
W_t = fspecial('gauss',[1 2*L],L); W_t = W_t/W_t(end/2); W_t = W_t(1:end/2);
W_t = repmat(reshape(W_t,1,1,L),[3 3 1]);
W = W_s.*W_t;

W_pre = W(:,:,1:end-1);

sals_ex = padarray(sals,[1 1 L],'symmetric');

% initialization
mask_ex = imfilter(sals_ex,W_sp,'symmetric');
mask_ex = Normalize3d(mask_ex) > .5;

sal_flt = imfilter(sals_ex,W_sp);
sal_flt = Normalize3d(sal_flt);

f = [.5 1 .5;1 0 1; .5 1 .5];

E = zeros(size(mask_ex,1),size(mask_ex,2));
% find the best mask that produces minimum error base on ICM
for frame=L+1:size(sals,3)+L
    sal = sal_flt(:,:,frame);
    localMinSal = imerode(sal, true(3));
    localMaxSal = imdilate(sal, true(3));
    mask = mask_ex(:,:,frame);
    for i=2:size(mask_ex,1)-1
        for j=2:size(mask_ex,2)-1
            if mask(i,j)
                a = (1-mask_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*W_pre;
                b = sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*W_pre;
                e_T = sum(a(:))/sum(b(:));
                e_O = 1 - localMaxSal(i,j);
                e_C = 1-sum(sum(f.*mask(i-1:i+1,j-1:j+1)))/6;
            else
                a = mask_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*(1-sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*W_pre;
                b = (1-sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*W_pre;
                e_T = sum(a(:))/sum(b(:));
                e_O = localMinSal(i,j);
                e_C = sum(sum(f.*mask(i-1:i+1,j-1:j+1)))/6;
            end
            E(i,j) = T_t*e_T + T_o*e_O + T_c*e_C;
        end
    end
  
    % change the mask of each block, and keep it if it causes error reduction
    for itr=1:MAX_ITR
        E_new = E;
        for i=2:size(mask_ex,1)-1
            for j=2:size(mask_ex,2)-1
                mask_ex(i,j,frame) = ~mask(i,j);
                if mask_ex(i,j,frame)
                    a = (1-mask_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*W_pre;
                    b = sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*W_pre;
                    e_T = sum(a(:))/sum(b(:));
                    e_O = 1 - localMaxSal(i,j);
                    e_C = 1-sum(sum(f.*mask_ex(i-1:i+1,j-1:j+1,frame)))/6;
                else
                    a = mask_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1).*(1-sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*W_pre;
                    b = (1-sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame-1)).*W_pre;
                    e_T = sum(a(:))/sum(b(:));
                    e_O = localMinSal(i,j);
                    e_C = sum(sum(f.*mask_ex(i-1:i+1,j-1:j+1,frame)))/6;
                end
                E_new(i,j) = T_t*e_T + T_o*e_O + T_c*e_C;
                mask_ex(i,j,frame) = ~mask_ex(i,j,frame);
            end
        end
        ind = E_new<E;
        if ~any(ind(:))
            break
        end
        mask(ind) = ~mask(ind);
        mask_ex(:,:,frame) = mask;
        E(ind) = E_new(ind);
    end
    % compute the saliency map based on saliency mask
    for i=2:size(mask_ex,1)-1
        for j=2:size(mask_ex,2)-1
            if mask_ex(i,j,frame)
                tmp = (sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame).*W);
                sal(i,j) = max(tmp(:));
            else
                tmp = (1-sals_ex(i-1:i+1,j-1:j+1,frame-L+1:frame)).*W;
                sal(i,j) = 1-max(tmp(:));
            end
        end
    end
    sals(:,:,frame-L) = sal(2:end-1,2:end-1);
end

mask = mask_ex(2:end-1,2:end-1,L+1:end-L);