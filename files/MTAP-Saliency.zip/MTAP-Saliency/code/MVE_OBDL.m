
function [Saliency]=MVE_OBDL(frameType, blkType, mv_x, mv_y, BLK_SZ, W,mem)
L = 5; % 200 ms (5 previous frames + itself)
% tic
mv_x = mv_x(:,:,frameType=='P');
mv_y = mv_y(:,:,frameType=='P');
mv_x = min(mv_x,16); mv_x = max(mv_x,-16); % corrected
mv_y = min(mv_y,16); mv_y = max(mv_y,-16); % corrected
blkType = blkType(:,:,:,frameType=='P');
[BLK_H,BLK_W,FRMS_CNT] = size(mv_x);

% increase artificially the visual attention of small blocks 
type = squeeze(blkType(:,:,2,:))=='+';
n = sum(type(:));
mv_x(type) = randi([-16,16],n,1);
mv_y(type) = randi([-16,16],n,1);

mv_x_ext = padarray(mv_x*4,[W,W,L],'symmetric'); % corrected
mv_y_ext = padarray(mv_y*4,[W,W,L],'symmetric'); % corrected
type = upper(squeeze(blkType(:,:,1,:)))=='I';
type_ext = padarray(type,[W,W,L],'symmetric');
%%

[x y]=meshgrid(-1:1,-1:1);
Mexp=exp(-(x.^2+y.^2)/(2*0.4593^2));



%%
Nmem=Normalize3d(mem);
obdl_flt=zeros(size(Nmem));
for frame=1:L
    obdl_flt(:,:,frame) = conv2(Nmem(:,:,frame),Mexp,'same');
end
% sfc_avg = sfc_flt;
for frame=L+1:FRMS_CNT
    obdl_flt(:,:,frame) = conv2(Nmem(:,:,frame),Mexp,'same');
    sfc_avg1(:,:,frame) = mean(obdl_flt(:,:,frame-L:frame),3);
end
sfc_avg1 = Normalize3d(sfc_avg1);
S_OBDL = imresize(sfc_avg1,4,'bilinear');
S_MVE = SalMVE_C(int32(mv_x_ext),int32(mv_y_ext),type_ext,W,L);
% toc
% tic
S_MVE = im2double(S_MVE(W+1:end-W,W+1:end-W,L+1:end-L));

S_MVE = Normalize3d(S_MVE);
%%
T_Sal=0.5*S_OBDL+S_MVE+0.75.*(S_OBDL.*S_MVE);
s_sum=sum(sum(T_Sal));

S_T=(T_Sal./s_sum);
S_g = imgaussfilt3(S_T, 1.5);
%%
Final_saliency=T_Sal.*S_g;
    S=Normalize3d(Final_saliency);

%%
zeroSaliency = find(sum(sum(S,1),2)==0);
if ~isempty(zeroSaliency)
    for i=1:numel(zeroSaliency)
        if zeroSaliency(i) == 1
            gaussMap = fspecial('gaussian',[BLK_H BLK_W],W); 
            % equal to pixel-based Gaussian blob of one visual digree
            S(:,:,1) = gaussMap / max(gaussMap(:));            
        else
            S(:,:,zeroSaliency(i)) = S(:,:,zeroSaliency(i)-1);
        end
    end
end
Saliency = zeros(BLK_H,BLK_W,length(frameType));
Saliency(:,:,frameType=='P') = S;
Saliency = imresize(Saliency,BLK_SZ,'nearest');
Saliency = uint8(Saliency*255);