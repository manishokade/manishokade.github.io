function nameFolds = MyDir(SEQ_DIR)

d = dir(SEQ_DIR);
isub = [d(:).isdir];
nameFolds = {d(isub).name}';
nameFolds(ismember(nameFolds,{'.','..'})) = [];