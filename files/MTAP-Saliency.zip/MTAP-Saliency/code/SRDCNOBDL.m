function [Saliency]=SRDCNOBDL(frameType,dct,mem)

BLK_SZ=4;
% BLK_H=72;
% BLK_W=88;
MBLK_SZ=16;
L=9;
% for i=1:3
% for j=1:3
% dis(i,j)=(i-x(i,j))^2+(j-y(i,j))^2;
% end
% end
% std(sqrt(dis(:)))
dct = abs(dct(:,:,:,frameType=='P'));
mem = (mem(:,:,frameType=='P'));
sz=size(dct,4);
% gi=ones(1,72,sz);
% gj=ones(1,88,sz);
% for i=1:72
%     gi(:,i,:)=i;
% end
% for j=1:88
%     gj(:,j,:)=j;
% end
% size(gi)
% sfc
dct_high = (dct);
sfc = Subsum(squeeze(dct_high(:,:,1,:)),MBLK_SZ,MBLK_SZ);
sfc_flt = zeros(size(sfc));
Nsfc=Normalize3d(sfc);
[x y]=meshgrid(-1:1,-1:1);
Mexp=exp(-(x.^2+y.^2)/(2*0.4593^2));
for frame=1:L
    sfc_flt(:,:,frame) = conv2(Nsfc(:,:,frame),Mexp,'same');
end
sfc_avg = sfc_flt;
for frame=L+1:size(sfc,3)
    sfc_flt(:,:,frame) = conv2(Nsfc(:,:,frame),Mexp,'same');
    sfc_avg(:,:,frame) = mean(sfc_flt(:,:,frame-L:frame),3);
end
sfc_avg = Normalize3d(sfc_avg);
S_SRN = imresize(sfc_avg,4,'bilinear');
Nmem=Normalize3d(mem);
obdl_flt=zeros(size(Nmem));
for frame=1:L
    obdl_flt(:,:,frame) = imfilter(Nmem(:,:,frame),Mexp,'conv');
end
sfc_avg1 = obdl_flt;
for frame=L+1:size(Nmem,3)
    obdl_flt(:,:,frame) = imfilter(Nmem(:,:,frame),Mexp,'conv');
    sfc_avg1(:,:,frame) = mean(obdl_flt(:,:,frame-L:frame),3);
end
% figure (34)
% imshow(sfc_avg1(:,:,3),[])
sfc_avg1 = Normalize3d(sfc_avg1);
S_OBDL = imresize(sfc_avg1,4,'bilinear');
T_Sal=S_OBDL+0.2.*S_SRN+0.6.*(S_OBDL.*S_SRN);

BLK_H=size(T_Sal,1);
BLK_W=size(T_Sal,2);
s_sum=sum(sum(T_Sal));
S_T=(T_Sal./s_sum);
% [x,y]  =meshgrid(BLK_H,BLK_W)  ;
% for t=1:size(T_Sal,3)
% S_T=(T_Sal./s_sum);
% et=S_T(:,:,t);
% 
%     for i=1:BLK_H
%     
% N_m(:,:,i)=et*i;
% end
% x_m=mean(N_m,3);
% for j=1:BLK_W
% % S_T=(T_Sal./s_sum);
% N_n(:,:,j)=et*j;
% end
%     y_m = mean(N_n,3);
%     
% S_g(:,:,t)=exp(-1.*((x-x_m).^2+(y-y_m).^2)./1.5);
% end
W=1.5;

S_g = imgaussfilt3(S_T, 3);

%%
Final_saliency=T_Sal.*S_g;
    S=Normalize3d(Final_saliency);
%%
zeroSaliency = find(sum(sum(S,1),2)==0);
if ~isempty(zeroSaliency)
    for i=1:numel(zeroSaliency)
        if zeroSaliency(i) == 1
            gaussMap = fspecial('gaussian',[BLK_H BLK_W],W); 
            % equal to pixel-based Gaussian blob of one visual digree
            S(:,:,1) = gaussMap / max(gaussMap(:));            
        else
            S(:,:,zeroSaliency(i)) = S(:,:,zeroSaliency(i)-1);
        end
    end
end
Saliency = zeros(BLK_H,BLK_W,length(frameType));
Saliency(:,:,frameType=='P') = S;
Saliency = imresize(Saliency,BLK_SZ,'nearest');
Saliency = uint8(Saliency*255);

