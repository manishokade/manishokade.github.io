#include <math.h>
#include "mex.h"
#include <string.h>
# include <omp.h>

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#if !defined(ABS)
#define	ABS(A)		((A) > 0 ? (A) : -(A))
#endif

#define EPS 2.2204e-016

#define MV_X(x,y,frame) mv_x[x+BLK_H*y+BLK_H*BLK_W*frame]
#define MV_Y(x,y,frame) mv_y[x+BLK_H*y+BLK_H*BLK_W*frame]
#define IS_INTRA(x,y,frame) isIntra[x+BLK_H*y+BLK_H*BLK_W*frame]

#define MSR (512*4) // Absolute maximum value for Motion Search Range

mxLogical *isIntra;
int *mv_x, *mv_y;
int A[2*MSR][2*MSR]; // 0 points to nothing, x points to x-th position (index: x-1) in NUM
int *NUM;
int BLK_H, BLK_W, FRMS_CNT, W, L, N, N_MAX;
int ptr; // new available position in NUM

void Add(int min_frame, int max_frame, int min_x, int max_x, int min_y, int max_y)
{
    int pA; // position reffered by A    
    int frame, x, y, i, sum;
    
    for (frame = min_frame; frame <= max_frame; frame++)
        for (x = min_x; x <= max_x; x++)
            for (y = min_y; y <= max_y; y++)
            {
                if (IS_INTRA(x,y,frame))
                    continue;
                N++;
                pA = A[MV_X(x,y,frame)+MSR][MV_Y(x,y,frame)+MSR];
                if (pA)
                {
                    pA = pA - 1;
                    NUM[pA]++;
                }
                else
                {
                    while (NUM[ptr])
                        if (++ptr == N_MAX)
                            ptr = 0;

                    NUM[ptr] = 1;

                    A[MV_X(x,y,frame)+MSR][MV_Y(x,y,frame)+MSR] = ptr+1;
                    if (++ptr == N_MAX)
                        ptr = 0;
                }
            }
}

void Remove(int min_frame, int max_frame, int min_x, int max_x, int min_y, int max_y)
{
    int pA; // position reffered by A
    int frame, x, y;
    
    for (frame = min_frame; frame <= max_frame; frame++)
        for (x = min_x; x <= max_x; x++)
            for (y = min_y; y <= max_y; y++)
            {
                if (IS_INTRA(x,y,frame))
                    continue;
                N--;
                pA = A[MV_X(x,y,frame)+MSR][MV_Y(x,y,frame)+MSR] - 1;
                if (--NUM[pA] == 0)
                    A[MV_X(x,y,frame)+MSR][MV_Y(x,y,frame)+MSR] = 0;
            }
}

void SalMVE(double S[])
{
    int i, frame, x, y;
    double sum, tmp;

    N = 0;
    N_MAX = (2*L+1)*(2*W+1)*(2*W+1);
    NUM = mxMalloc(sizeof(int)*N_MAX);
		memset(NUM,0,sizeof(int)*N_MAX);
		memset(A,0,sizeof(int)*4*MSR*MSR);
		ptr = 0;

    for (frame = L; frame < FRMS_CNT-L; frame++)
        for (x = W; x < BLK_H-W; x++)
        {
            // initialization
            Add(frame-L, frame, x-W, x+W, 0, 2*W-1);

            for (y = W; y < BLK_W-W; y++)
            {
                // Add(frame-L, frame+L, x-W, x+W, y+W, y+W);
                Add(frame-L, frame, x-W, x+W, y+W, y+W);
                for (i = 0, sum = 0; i < N_MAX; i++)
                    if (NUM[i])
                    {
                        tmp = (double)NUM[i]/(double)N;
                        sum = sum + tmp*log(tmp);
                    }
                if (N <= 1)
                    S[x+BLK_H*y+BLK_H*BLK_W*frame] = 0;
                else
                    S[x+BLK_H*y+BLK_H*BLK_W*frame] = -sum/log(N);

                Remove(frame-L, frame, x-W, x+W, y-W, y-W);
            }
            Remove(frame-L, frame, x-W, x+W, y-W, BLK_W-1);
        }
    
    // release memory
    mxFree(NUM);
}

void mexFunction(int nlhs, mxArray *plhs[],
        int nrhs, const mxArray *prhs[])
{
    const mwSize *dims;    
    double *S;
    int i;
    
    /* Check for proper number of arguments */
    if (nrhs != 5)
        mexErrMsgTxt("5 input arguments required.");
    else if (nlhs != 1)
        mexErrMsgTxt("1 output argument required.");
    
    /* Assign pointers to the input arguments */
    mv_x = (int *)mxGetData(prhs[0]);
    mv_y = (int *)mxGetData(prhs[1]);
    isIntra = (mxLogical *)mxGetData(prhs[2]);
    W = (int)*mxGetPr(prhs[3]);
    L = (int)*mxGetPr(prhs[4]);
    
    dims = mxGetDimensions(prhs[0]);
    BLK_H = (int)dims[0];
    BLK_W = (int)dims[1];
    FRMS_CNT = (int)dims[2];
    
    /* Create matrises for the return arguments */
    plhs[0] = mxCreateNumericArray(3, dims, mxDOUBLE_CLASS, mxREAL);
    
    /* Assign pointers to the output arguments */
    S = mxGetPr(plhs[0]);
    
    /* Do the actual computations in a subroutine */
    SalMVE(S);
    
    return;
}
