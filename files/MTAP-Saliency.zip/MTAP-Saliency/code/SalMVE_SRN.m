% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% Motion Vector Anthropy based saliency estimation 
%
% Input
%     frameType: (array) frame types
%     mv_x: (3-D matrix) x-component of motion vecters 
%     mv_y: (3-D matrix) y-component of motion vecters
%     BLK_SZ: (integer value) block size
%     
% Output
%     Saliency: (3-D matrix) predicted saliency map

function [Saliency,Saliency_MVE,Saliency_SRN] = SalMVE_SRN(frameType, blkType, mv_x, mv_y, BLK_SZ, W, dct)
L = 5; % 200 ms (5 previous frames + itself)

mv_x = mv_x(:,:,frameType=='P');
mv_y = mv_y(:,:,frameType=='P');
mv_x = min(mv_x,16); mv_x = max(mv_x,-16); % corrected
mv_y = min(mv_y,16); mv_y = max(mv_y,-16); % corrected
blkType = blkType(:,:,:,frameType=='P');
[BLK_H,BLK_W,FRMS_CNT] = size(mv_x);

% increase artificially the visual attention of small blocks 
type = squeeze(blkType(:,:,2,:))=='+';
n = sum(type(:));
mv_x(type) = randi([-16,16],n,1);
mv_y(type) = randi([-16,16],n,1);

mv_x_ext = padarray(mv_x*4,[W,W,L],'symmetric'); % corrected
mv_y_ext = padarray(mv_y*4,[W,W,L],'symmetric'); % corrected
type = upper(squeeze(blkType(:,:,1,:)))=='I';
type_ext = padarray(type,[W,W,L],'symmetric');

%% Entropy of motion vectors
% using mex file
S_MVE = SalMVE_C(int32(mv_x_ext),int32(mv_y_ext),type_ext,W,L);
% using matlab operations
% N = (2*Ls+1)*(2*W+1)*(2*W+1);
% S_MVE = zeros(size(mv_x)+[W W Ls]);
% for frame=Ls+1:FRMS_CNT+Ls
%     for i=W+1:BLK_H+W
%         for j=W+1:BLK_W+W
%             x = mv_x_ext(i-W:i+W,j-W:j+W,frame-Ls:frame);
%             y = mv_y_ext(i-W:i+W,j-W:j+W,frame-Ls:frame);
%             x = x(:); y = y(:);
%             a = x*10000+y; % convert two numbers to a unique number
%             numbersa=unique(a);
%             
%             x = mv_x_ext(i-W:i+W,j-W:j+W,frame-Ls:frame-1);
%             y = mv_y_ext(i-W:i+W,j-W:j+W,frame-Ls:frame-1);
%             x = x(:); y = y(:);
%             b = x*10000+y; % convert two numbers to a unique number
%             numbersb=unique(b);
%             numbers = union(numbersa,numbersb);
%             if numel(numbers)==1
%                 S_MVE(i,j,frame) = 0;
%             else
%                 count=hist(a,numbers)/N;
%                 S_MVE(i,j,frame) = -sum(count.*log2(count));
%             end
%         end
%     end
% end
S_MVE = S_MVE(W+1:end-W,W+1:end-W,L+1:end-L);
S_MVE = Normalize3d(S_MVE);

%% prediction texture residuals
MBLK_SZ = BLK_SZ*4;
dct = abs(dct(:,:,:,frameType=='P'));
%%
% sfc
dct_high = logical(dct);
sfc = Subsum(squeeze(dct_high(:,:,1,:)),MBLK_SZ,MBLK_SZ);
sfc_flt = zeros(size(sfc));
for frame=1:L
    sfc_flt(:,:,frame) = imfilter(sfc(:,:,frame),ones(3));
end
sfc_avg = sfc_flt;
for frame=L+1:size(sfc,3)
    sfc_flt(:,:,frame) = imfilter(sfc(:,:,frame),ones(3));
    sfc_avg(:,:,frame) = mean(sfc_flt(:,:,frame-L:frame),3);
end
sfc_avg = Normalize3d(sfc_avg);
S_SRN = imresize(sfc_avg,4,'bilinear');
%%


% MBLK_SZ = BLK_SZ*4;
% dctLuma = squeeze(dct(:,:,1,:));
% edg = double(abs(dctLuma(2:MBLK_SZ:end,1:MBLK_SZ:end,:))+abs(dctLuma(1:MBLK_SZ:end,2:MBLK_SZ:end,:)));
% edg_norm = imresize(Normalize3d(edg),4,'bilinear');






%%
% dct = abs(dct);
% tmp = sort(reshape(dct,[],1),'descend');
% TH = tmp(floor(numel(tmp)*.25));
% dct_high = dct > TH;
% sfc = Subsum(squeeze(dct_high(:,:,1,:)),MBLK_SZ,MBLK_SZ) + ...
%     imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,2,:)),MBLK_SZ,MBLK_SZ),2,'nearest') + ...
%     imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,3,:)),MBLK_SZ,MBLK_SZ),2,'nearest');
% sfc_norm = imresize(Normalize3d(sfc),4,'bilinear');
% S_SRN=sfc_norm;
% sfc_flt = zeros(size(sfc));
% for frame=1:L
%     sfc_flt(:,:,frame) = imfilter(sfc(:,:,frame),ones(3));
% end
% sfc_avg = sfc_flt;
% for frame=L+1:size(sfc,3)
%     sfc_flt(:,:,frame) = imfilter(sfc(:,:,frame),ones(3));
%     sfc_avg(:,:,frame) = mean(sfc_flt(:,:,frame-L:frame),3);
% end
% sfc_avg = Normalize3d(sfc_avg);
% S_SRN = imresize(sfc_avg,4,'bilinear');
%%
S = S_MVE + S_SRN + S_MVE .* S_SRN ;
S = Normalize3d(S);

% handle when no saliency is detected for a frame
zeroSaliency = find(sum(sum(S,1),2)==0);
if ~isempty(zeroSaliency)
    for i=1:numel(zeroSaliency)
        if zeroSaliency(i) == 1
            gaussMap = fspecial('gaussian',[BLK_H BLK_W],W); 
            % equal to pixel-based Gaussian blob of one visual digree
            S(:,:,1) = gaussMap / max(gaussMap(:));            
        else
            S(:,:,zeroSaliency(i)) = S(:,:,zeroSaliency(i)-1);
        end
    end
end
 
Saliency = zeros(BLK_H,BLK_W,length(frameType));
Saliency(:,:,frameType=='P') = S;
Saliency = imresize(Saliency,BLK_SZ,'nearest');
Saliency = uint8(Saliency*255);

Saliency_MVE = zeros(BLK_H,BLK_W,length(frameType));
Saliency_MVE(:,:,frameType=='P') = S_MVE;
Saliency_MVE = imresize(Saliency_MVE,BLK_SZ,'nearest');
Saliency_MVE = uint8(Saliency_MVE*255);

Saliency_SRN = zeros(BLK_H,BLK_W,length(frameType));
Saliency_SRN(:,:,frameType=='P') = S_SRN;
Saliency_SRN = imresize(Saliency_SRN,BLK_SZ,'nearest');
Saliency_SRN = uint8(Saliency_SRN*255);

