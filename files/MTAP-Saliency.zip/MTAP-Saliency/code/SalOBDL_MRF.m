function Saliency = SalOBDL_MRF(mem, ONE_DEGREE_MBLKS, T_t, T_o, T_c)

if nargin < 3
    T_t=1;
    T_o=1;
    T_c=1;
end

mem = Normalize3d(mem);
mem = imfilter(mem,fspecial('gauss',3,ONE_DEGREE_MBLKS*2));
mem = Normalize3d(mem);

L = 2;
flt = ones(1,1,2*L-1); flt(L+1:end) = 0;
sal = imfilter(mem,flt,'symmetric');
sal = Normalize3d(sal);
size(sal)
sal = ICM(sal,14,ONE_DEGREE_MBLKS,T_t,T_o,T_c);
S = Normalize3d(sal);

S = imresize(S,4,'bilinear');
S = Normalize3d(S);

% handle when no saliency is detected for a frame
zeroSaliency = find(sum(sum(S,1),2)==0);
if ~isempty(zeroSaliency)
    for i=1:numel(zeroSaliency)
        if zeroSaliency(i) == 1
            gaussMap = fspecial('gaussian',[size(S,1) size(S,2)],ONE_DEGREE_MBLKS/4);
            % equal to pixel-based Gaussian blob of one visual digree
            S(:,:,1) = gaussMap / max(gaussMap(:));
        else
            S(:,:,zeroSaliency(i)) = S(:,:,zeroSaliency(i)-1);
        end
    end
end

S = imresize(S,4,'nearest');
Saliency = uint8(S*255);