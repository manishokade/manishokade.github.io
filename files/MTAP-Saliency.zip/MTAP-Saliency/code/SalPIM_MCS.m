% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% saliency estimation based on
%
% A. Sinha, G. Agarwal, and A. Anbu, �Region-of-interest based compressed
% domain video transcoding scheme,� in Proc. IEEE ICASSP�04,
% vol. 3. IEEE, 2004, pp. 161�164.
%
% Input
%     frameType: (array) frame types
%     blkType: (3-D matrix) block types
%     mv_x: (3-D matrix) x-component of motion vecters 
%     mv_y: (3-D matrix) y-component of motion vecters
%     dct: (4-D matrix) DCT values of macroblocks of types Y/Cb/Cr
%     BLK_SZ: (integer value) block size
%     
% Output
%     Saliency: (3-D matrix) predicted saliency map

function Saliency = SalPIM_MCS(frameType,blkType,mv_x,mv_y,dct,BLK_SZ)

% NOTE: no information about low-pass filter is given in the paper
%       we use the following filter
LPF = fspecial('gaussian',5,1);

% remove the intra-coded and skip MBs from P-frames
pFrms = frameType=='P';
blkTypeP = squeeze(blkType(:,:,1,pFrms));
invalid = upper(blkTypeP) == 'I' | blkTypeP == 'S';
invalidMBs = false(size(dct));
invalidMBs(:,:,1,pFrms) = imresize(invalid,BLK_SZ,'nearest');
invalidMBs(1:end/2,1:end/2,2,pFrms) = imresize(invalid,BLK_SZ/2,'nearest');
invalidMBs(1:end/2,1:end/2,3,pFrms) = invalidMBs(1:end/2,1:end/2,2,pFrms);
dct(invalidMBs) = 0;

mv_x = mv_x(:,:,frameType=='P');
mv_y = mv_y(:,:,frameType=='P');
dct = dct(:,:,:,frameType=='P');
% blkType = squeeze(blkType(:,:,1,frameType=='P'));
% intraBlks = upper(blkType) == 'I';
% [mv_x,mv_y] = ApproxIntra(mv_x, mv_y, intraBlks, BLK_SZ);

[BLK_H,BLK_W,FRMS_CNT] = size(mv_x);

%% compute normalized motion magnitude
mag = abs(mv_x)+abs(mv_y);
sad = 1+double(abs(squeeze(dct(1:BLK_SZ:end,1:BLK_SZ:end,1,:))))/(BLK_SZ^4);
mag_A = (mag.^2)./sad;

mag_B = zeros(size(mag));
for frame=1:FRMS_CNT
    mag_lpf = filter2(LPF,mag(:,:,frame));
    tmp = mag_lpf(1:2:end,1:2:end);
    tmp = kron(tmp,ones(2));
    mag_B(:,:,frame) = abs(mag_lpf-tmp);
end

mag_norm = Normalize3d(Normalize3d(mag_A)+Normalize3d(mag_B));

%% compute edge energy (the same as Agrawal_2003)
% based on
%   B. Shen et al, "Convoludon-based edge detecrion for image/video in block
%   DCT domain"
% and
%   K. Muthuswamy et at, "Salient Motion Detection in Compressed Domain"
MBLK_SZ = BLK_SZ*4;
dctLuma = squeeze(dct(:,:,1,:));
edg = double(abs(dctLuma(2:MBLK_SZ:end,1:MBLK_SZ:end,:))+abs(dctLuma(1:MBLK_SZ:end,2:MBLK_SZ:end,:)));
edg_norm = imresize(Normalize3d(edg),4,'bilinear');

%% compute Spatial Frequency Content (SFC) (the same as Agrawal_2003)
dct = abs(dct);
tmp = sort(reshape(dct,[],1),'descend');
TH = tmp(floor(numel(tmp)*.25));
dct_high = dct > TH;
sfc = Subsum(squeeze(dct_high(:,:,1,:)),MBLK_SZ,MBLK_SZ) + ...
    imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,2,:)),MBLK_SZ,MBLK_SZ),2,'nearest') + ...
    imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,3,:)),MBLK_SZ,MBLK_SZ),2,'nearest');
sfc_norm = imresize(Normalize3d(sfc),4,'bilinear');

%% final saliency
S = 4*mag_norm + edg_norm + 2*sfc_norm;
S = Normalize3d(S);
Saliency = zeros(BLK_H,BLK_W,length(frameType));
Saliency(:,:,frameType=='P') = S;
Saliency = imresize(Saliency,BLK_SZ,'nearest');
Saliency = uint8(Saliency*255);
