% Written by S. Hossein Khatoonabadi (skhatoon@sfu.ca)
%
% saliency estimation based on
%
% G. Agarwal, A. Anbu, and A. Sinha, �A fast algorithm to find the regionof-
% interest in the compressed MPEG domain,� in Proc. IEEE ICME�03,
% vol. 2. IEEE, 2003, pp. 133�136.
%
% Input
%     frameType: (array) frame types
%     blkType: (3-D matrix) block types
%     mv_x: (3-D matrix) x-component of motion vecters 
%     mv_y: (3-D matrix) y-component of motion vecters
%     dct: (4-D matrix) DCT values of macroblocks of types Y/Cb/Cr
%     BLK_SZ: (integer value) block size
%     
% Output
%     Saliency: (3-D matrix) predicted saliency map

function Saliency = SalPIM_ZEN(frameType,blkType,mv_x,mv_y,dct,BLK_SZ)

% define constants for outliers detection
W = 2;
DELTA_THETA = pi/6;
TH_CNT = W+1;

% remove the intra-coded and skip MBs from P-frames
pFrms = frameType=='P';
blkTypeP = squeeze(blkType(:,:,1,pFrms));
invalid = upper(blkTypeP) == 'I' | blkTypeP == 'S';
invalidMBs = false(size(dct));
invalidMBs(:,:,1,pFrms) = imresize(invalid,BLK_SZ,'nearest');
invalidMBs(1:end/2,1:end/2,2,pFrms) = imresize(invalid,BLK_SZ/2,'nearest');
invalidMBs(1:end/2,1:end/2,3,pFrms) = invalidMBs(1:end/2,1:end/2,2,pFrms);
dct(invalidMBs) = 0;

mv_x = mv_x(:,:,frameType=='P');
mv_y = mv_y(:,:,frameType=='P');
dct = dct(:,:,:,frameType=='P');

[BLK_H,BLK_W,FRMS_CNT] = size(mv_x);

%% compute normalized motion magnitude
mag = abs(mv_x)+abs(mv_y);
mv_x_ext = padarray(mv_x,[W,W],'symmetric');
mv_y_ext = padarray(mv_y,[W,W],'symmetric');

% detect outliers/noise, based on
%   H. Zen et al., "Moving object detection from MPEG coded picture"
MIDDLE = ((2*W+1)^2-1)/2;
for frame=1:FRMS_CNT
    for i=W+1:BLK_H+W
        for j=W+1:BLK_W+W
            x = mv_x_ext(i-W:i+W,j-W:j+W,frame); x = x(:);
            y = mv_y_ext(i-W:i+W,j-W:j+W,frame); y = y(:);
            angles = atan2(y,x);
            delta_angles = abs(angles(MIDDLE)-angles);
            delta_lens = abs(x(MIDDLE)-x)+abs(y(MIDDLE)-y);
            if sum(delta_angles <= DELTA_THETA & delta_lens <= 1) < TH_CNT
                % interpolate the motion vector from neighbors
                x(MIDDLE) = []; y(MIDDLE) = [];
                tmp = abs(x)+abs(y);
                mag(i-W,j-W,frame) = median(tmp);
            end
        end
    end
end
mag_norm = Normalize3d(mag);

%% compute edge energy
% based on
%   B. Shen et al, "Convoludon-based edge detecrion for image/video in block
%   DCT domain"
% and
%   K. Muthuswamy et at, "Salient Motion Detection in Compressed Domain"
MBLK_SZ = BLK_SZ*4;
dctLuma = squeeze(dct(:,:,1,:));
edg = double(abs(dctLuma(2:MBLK_SZ:end,1:MBLK_SZ:end,:))+abs(dctLuma(1:MBLK_SZ:end,2:MBLK_SZ:end,:)));
edg_norm = imresize(Normalize3d(edg),4,'bilinear');

%% compute Spatial Frequency Content (SFC)
dct = abs(dct);
tmp = sort(reshape(dct,[],1),'descend');
TH = tmp(floor(numel(tmp)*.25));
dct_high = dct > TH;
sfc = Subsum(squeeze(dct_high(:,:,1,:)),MBLK_SZ,MBLK_SZ) + ...
    imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,2,:)),MBLK_SZ,MBLK_SZ),2,'nearest') + ...
    imresize(Subsum(squeeze(dct_high(1:end/2,1:end/2,3,:)),MBLK_SZ,MBLK_SZ),2,'nearest');
sfc_norm = imresize(Normalize3d(sfc),4,'bilinear');

%% final saliency
S = mag_norm + edg_norm + sfc_norm;
S = Normalize3d(S);
Saliency = zeros(BLK_H,BLK_W,length(frameType));
Saliency(:,:,frameType=='P') = S;
Saliency = imresize(Saliency,BLK_SZ,'nearest');
Saliency = uint8(Saliency*255);
