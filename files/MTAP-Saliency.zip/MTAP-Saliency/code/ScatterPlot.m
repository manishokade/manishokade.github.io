clc;
clear all;
close all;




SEQ={'SOCCER','TEMPETE',  'CREW','BUS','CITY','STEFAN','MOBILE','MOTHER','FOREMAN','GARDEN','HALL','HARBOUR'}
FRAME_CNT={250,250,137,150,150, 75,250,250,250,250,250,250};

lq=1;
% sd1=liftwave('haar');

tic
for iw=1:numel(SEQ)
    
    
    Sal_path=['F:\CSE-Software\SEQ_SFU\',SEQ{iw},'\result_PROPOSEDsal_H264_QP30.mat']
%     path1=['G:\Research-2\S.Pavan\CSE-Software\SEQ_SFU\',SEQ{iw},'\H264_QP30\mv_'];
    p1=['F:\CSE-Software\SEQ_SFU\',SEQ{iw},'\gazeloc.mat'];
%     path=['G:\Research-2\S.Pavan\CSE-Software\SEQ_SFU\',SEQ{iw},'\H264_QP30\dct_'];
    OP=load(p1);
    SAL =load(Sal_path);
    S_map= SAL.S;
    MN=size(S_map,3);
    GL=OP.gazeLoc;
    I5=Normalize3d(S_map);
%     I5=S_map;
for frame = 2:FRAME_CNT{iw}
      OGL= GL(frame,:);
    Ix=I5(:,:,frame-1);lo=1;
      for i=1:2:59
      PX(lo)=Ix(ceil(OGL(1,i+1)),ceil(OGL(1,i)));
      Ix(ceil(OGL(1,i+1)),ceil(OGL(1,i)))=0;
      lo=lo+1;
      end
      Iy=mean(Ix(:));
      Iz=mean(PX);

      S_x(:,lq)=Iz;
      S_y(:,lq)=Iy;

lq=lq+1;
end
% figure (2)
% imshow(S_SRN1(:,:,3),[])
end
toc

%% Scatter plot


figure (3)
plot(0:0.5:1,0:0.5:1)
hold on
scatter(S_y(:),S_x(:),'.')
xlim([0 1])
ylim([0 1])
xlabel('control sample mean')
ylabel('test sample mean')
box on