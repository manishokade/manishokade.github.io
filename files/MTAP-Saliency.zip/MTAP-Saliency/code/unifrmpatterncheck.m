function [Ex]=unifrmpatterncheck(E)
unipat=[0;1;2;3;4;6;7;8;12;14;15;16;24;28;30;31;32;48;56;60;62;63;64;96;112;120;124;126;127;128;129;131;135;143;159;191;192;193;195;199;207;223;224;225;227;231;239;240;241;243;247;248;249;251;252;253;254;255];
    %"unipat have all 58 uniform patterns"
    [w1, w2]=size(E);
    for i=1:w1
        for j=1:w2
            for k=1:size(unipat,1)
                if E(i,j)==unipat(k)
                    Ex(i,j,k)=1;
                else
                    Ex(i,j,k)=0;
                end
            end
        end
    end
    Ex=sum(Ex,3);
    Ex=1-Ex;