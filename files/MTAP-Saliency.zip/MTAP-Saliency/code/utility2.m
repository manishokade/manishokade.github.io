function [wx1 wp1 ws1 wy1 wz1]= utility2(sx,sb,sa1,sa2,sb2,sa3,sa4,sa5,sa6,sa7,sa8,sb1,sb3,sb4,sb5,sb6,sb7,sb8,lx1,l1,l2,l3,l4,l5,l6,l7,l8)
wx1=zeros(3,3);
wy1=zeros(3,3);
wz1=zeros(3,3);
ws1=zeros(3,3);
wp1=zeros(3,3);
if sx-sa1>=0 && sb-sb1>=0 
  wx1(2,3)=1  ;
 end
 if sx-sa2>=0 && sb-sb2>=0 
  wx1(1,3)=1  ;
 end
 if sx-sa3>=0 && sb-sb3>=0 
  wx1(1,2)=1  ;
 end
 if sx-sa4>=0 && sb-sb4>=0 
  wx1(1,1)=1  ;
 end
 if sx-sa5>=0 && sb-sb5>=0 
  wx1(2,1)=1  ;
 end
 if sx-sa6>=0 && sb-sb6>=0 
  wx1(3,1)=1  ;
 end
 if sx-sa7>=0 && sb-sb7>=0 
  wx1(3,2)=1  ;
 end
 if sx-sa8>=0 && sb-sb8>=0 
  wx1(3,3)=1  ;
 end
 %%
 if sx-sa1<0 && sb-sb1<0 
  wp1(2,3)=1  ;
 end
 if sx-sa2<0 && sb-sb2<0 
  wp1(1,3)=1  ;
 end
 if sx-sa3<0 && sb-sb3<0 
  wp1(1,2)=1  ;
 end
 if sx-sa4<0 && sb-sb4<0 
  wp1(1,1)=1  ;
 end
 if sx-sa5<0 && sb-sb5<0 
  wp1(2,1)=1  ;
 end
 if sx-sa6<0 && sb-sb6<0 
  wp1(3,1)=1  ;
 end
 if sx-sa7<0 && sb-sb7<0 
  wp1(3,2)=1  ;
 end
 if sx-sa8<0 && sb-sb8<0 
  wp1(3,3)=1  ;
 end
 %%
 if sx-sa1<0 && sb-sb1>=0 
  ws1(2,3)=1  ;
 end
 if sx-sa2<0 && sb-sb2>=0 
  ws1(1,3)=1  ;
 end
 if sx-sa3<0 && sb-sb3>=0 
  ws1(1,2)=1  ;
 end
 if sx-sa4<0 && sb-sb4>=0 
  ws1(1,1)=1  ;
 end
 if sx-sa5<0 && sb-sb5>=0 
  ws1(2,1)=1  ;
 end
 if sx-sa6<0 && sb-sb6>=0 
  ws1(3,1)=1  ;
 end
 if sx-sa7<0 && sb-sb7>=0 
  ws1(3,2)=1  ;
 end
 if sx-sa8<0 && sb-sb8>=0 
  ws1(3,3)=1  ;
 end
 %%
 if sx-sa1>=0 && sb-sb1<0 
  wy1(2,3)=1  ;
 end
 if sx-sa2>=0 && sb-sb2<0 
  wy1(1,3)=1  ;
 end
 if sx-sa3>=0 && sb-sb3<0 
  wy1(1,2)=1  ;
 end
 if sx-sa4>=0 && sb-sb4<0 
  wy1(1,1)=1  ;
 end
 if sx-sa5>=0 && sb-sb5<0 
  wy1(2,1)=1  ;
 end
 if sx-sa6>=0 && sb-sb6<0 
  wy1(3,1)=1  ;
 end
 if sx-sa7>=0 && sb-sb7<0 
  wy1(3,2)=1  ;
 end
 if sx-sa8>=0 && sb-sb8<0 
  wy1(3,3)=1  ;
 end
 %% Length 
 if lx1-l1<=0 
  wz1(2,3)=1  ;
 end
 if lx1-l2<=0 
  wz1(1,3)=1  ;
 end
 if lx1-l3<=0 
  wz1(1,2)=1  ;
 end
 if lx1-l4<=0 
  wz1(1,1)=1  ;
 end
 if lx1-l5<=0 
  wz1(2,1)=1  ;
 end
 if lx1-l6<=0 
  wz1(3,1)=1  ;
 end
 if lx1-l7<=0 
  wz1(3,2)=1  ;
 end
 if lx1-l8<=0 
  wz1(3,3)=1  ;
 end