 function dct_jpeg1= dct_tst(c,x,im_gray)



%%shift the pixels by -128 to get values between -28 and 127
im_sub1=im_gray-128;
[a b]=size(im_sub1);
if(mod(a,8)~=0)
    im_sub1=padarray(im_sub1,[8,0],0,'post');
end
if(mod(b,8)~=0)
    im_sub1=padarray(im_sub1,[0,8],0,'post');
end
%dct on each 8*8 window
dct_jpeg1=bdct(im_sub1,8);
[a b]=size(dct_jpeg1);

%extracting specific components i.e(c,x) of each 8*8 window
% for k1=1:8
%     for k2=1:8 
%         for i=0:(a/8)-1
%             for j=0:(b/8)-1
%                 a1(i+1,j+1,k1,k2)=dct_jpeg1(8*i+k1,8*j+k2);
%             end
%         end
%     end
% end
% 
% p=reshape(a1(:,:,c,x),1,a*b/64);
