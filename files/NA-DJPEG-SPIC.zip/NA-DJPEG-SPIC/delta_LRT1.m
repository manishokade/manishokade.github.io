 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These codes are written by Prof. Jayanta Mukherjee, IIT Kharagpur during 2008 to  2011. The codes may be used freely for 
% any academic and research purpose with appropriate acknowledgment. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Y=delta_LRT1(X,delta)
% Computes delta local rank transform of an gray scale image X

Y=zeros(1,length(X));

for i=1:length(X)
    %for j=1:width
        rank_count=0;
        for k=-1:2:1
            %for l=-1:2:1
                if(((i+k)>0) && ((i+k)<=length(X)))
     %               if(((j+l)>0) && ((j+l)<=width))
                        if(X(i+k)>X(i)-delta)
                        
                            rank_count=rank_count+1;
                         end
                end
        end
         Y(1,i)=rank_count;
end
return