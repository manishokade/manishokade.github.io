function [c11 c1]=filter_br(countp1,p4,Ts1,c,x,n1,mn1,kp)
%%%%%%%%%RIGHT HALF FILTERING%%%%%%%%%%%%%%%%%%%%%%%%
countp9=countp1(-min(p4)+2:length(countp1));
m=1;
a=100;
con9= countp9;
% RESIDUAL NOISE FILTERING
y=delta_LRT1(con9,10);
 for i=1:length(y)
     if(y(i)==2)
         countp9(i)=0;
     end
 end
%% BAE FILTERING 
 [b1 l1]=size(countp9);
 countp2=zeros([b1,l1]);
 while(a>=2) 
     [a k]=max(countp9(1:length(countp9)));
     countp2(k)=a;
     countp9(1:k)=0;
 end

p7=countp2;

[a b]=size(kp);
c1=zeros([a,1]);
c2=zeros([a,1]);
for i=1:a
    for j=1:b
        if(kp(i,j)~=0)
        if(countp2(kp(i,j))~=0)
            c1(i)=c1(i)+1;
        end
        else
            c2(i)=j-1;
            break;

        end
    end
end

for i=1:length(c2)
    if(c2(i)==0)
        c2(i)=b;
    end
end
c1_1=c1;
c11=c1./c2';
for i=1:length(countp2)
        if(countp2(i)~=0)
            [a1 b1]=find(i==kp);
            [a2 b2]=size(a1);

            if(b2~=0)
               c1=c1+1;
            end
        end
end
