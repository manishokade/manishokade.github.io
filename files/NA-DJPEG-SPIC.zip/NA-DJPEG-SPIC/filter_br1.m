function [c11 c1 c2]=filter_br1(countp1,p4,Ts1,c,x,n1,mn1,kp)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
countp91=countp1(1:-min(p4));

con91=countp91;
a=100;
%% RESIDUAL NOISE FILTERING
 y1=delta_LRT1(countp91,10);
 for i=1:length(y1)
     if(y1(i)==2)
         countp91(i)=0;
     end
 end

 for i=1:length(countp91)
     countp92(length(countp91)-i+1)=countp91(i);
 end
%% BAE FILTERING
countp91=countp92;
[l1 b1]=size(countp91);
countp21=zeros([l1,b1]);
 while(a>=2) 
     [a kq1]=max(countp91(1:length(countp91)));
     countp21(kq1)=a;
     countp91(1:kq1)=0;
 end
 p71=countp21;

[a b]=size(kp);
c1=zeros([a,1]);
c2=zeros([a,1]);
for i=1:a
    for j=1:b
        if(kp(i,j)~=0)
            if(countp21(abs(kp(i,j)))~=0)
                c1(i)=c1(i)+1;
            end
        else
            c2(i)=j-1;
            break;
        end
    end
end

for i=1:length(c2)
    if(c2(i)==0)
        c2(i)=b;
    end
end
c1_1=c1;
c11=c1./c2';
for i=1:length(countp21)
        if(countp21(i)~=0)
            [a1 b1]=find(-i==kp);
            [a2 b2]=size(a1);

            if(b2~=0)
               c1=c1+1;
            end
        end
end
