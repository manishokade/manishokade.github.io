function [p7,a1,difsum1,dif1,q_final,c1]=hist_comp(k1,dp,Ts1,c,x,p4,countp1)
%  k1 is the list of values selected which might be the first quantization step
% hout is the histogram wrt to quantization values
%dct_jpeg2= dct coeff of given image
%Ts1= quantization table


[p q]=size(dp); %%double compressed image extracted

for s1=4:p
    for s2=4:q
        im_cropped(s1,s2)=dp(s1,s2);    %%size by which the image is to be cropped
    end
end
[m n]=size(im_cropped);
[m2 m1]=size(k1);

[max_countp1 max_countp1_dim]=max(countp1);
[r1 r2]=size(countp1);

dif1=[];
dif11=[];
im_cropped=dct_tst(c,x,im_cropped);
for i=1:m1
     
    if(k1(i)>0)


        %quantization table (constant quantization table considered where all the values are same based on possible value of q1 i.e q3)
        Ts3=k1(i)*ones(8,8);

        %quantization
        quant_cropped1=quantize(im_cropped,Ts3);
        
        %dequantization
        dequant_cropped1=dequantize(quant_cropped1,Ts3);
        
        %IDCT
       jpeg_3final=mainhis1_idct(dequant_cropped1);
        [a b]=size(jpeg_3final);
       %DCT
        dct_jpeg23= mainhis2_dct(jpeg_3final);
       
        %%QUANTIZATION JPEG-II
        [quantization_jpeg23, p7]= mainhis2_qnt(c,x,dct_jpeg23,Ts1);
        m11=floor(min(p7));
        m21=ceil(max(p7));
        m0=ceil(m21)-floor(m11);
        [a1, b1]=size(p7);

 
        
   
        for k2=(m11):(m21)
            count1(k2-m11+1)=0;
            for i1=1:a1
                for j=1:b1
                    
                    if(k2==round(p7(i1,j)))
                    
                        count1(k2-m11+1)=count1(k2-m11+1)+1;
                
                    end
                 
                end

            end
         
        end
            [t1 t2]=size(count1);
                if(i==7)
                c1=count1;
                end
           % figure
            %stem(count1);
          [max_count1 max_count1_dim]=max(count1);
       %%count1== histogram created after processing
          if(max_count1_dim==max_countp1_dim)
              if(t2==r2)
                  dif11=countp1-count1;
                  
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);
                
                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');  
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                    dif1(:,i)=transpose(dif11);
              end
              if(t2>r2)
                  countp11=padarray(countp1,[0,t2-r2],0,'post');
                  dif11=countp11-count1;
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);
%                   disp(size(dif11));
%                   disp(size(dif1));
                  
                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
%                  disp(size(dif11));
%                  disp(size(dif1));
                  dif1(:,i)=transpose(dif11);
              end
              
              if(t2<r2)
                  count11=padarray(count1,[0,r2-t2],0,'post');
                  dif11=countp1-count11;
              %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);

                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                  dif1(:,i)=transpose(dif11);
              end
          end
          if(max_count1_dim>max_countp1_dim)
              countp11=padarray(countp1,[0,max_count1_dim-max_countp1_dim],0,'pre');
              [r3 r4]=size(countp11);
              if(r4==t2)
                  dif11=countp11-count1;
                
                %%equalization
                
                [h1 h2]=size(dif11);
                [h3 h4]=size(dif1);
       
               
                if(h2>h3)
                    dif1=padarray(dif1,[h2-h3,0],0,'post');
                end
                if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                end
                  dif1(:,i)=transpose(dif11);
              end
              
              if(r4>t2)
                  count11=padarray(count1,[0,r4-t2],0,'post');
                  dif11=countp11-count11;
              
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);

                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                  dif1(:,i)=transpose(dif11);
              end
              if(r4<t2)
                  countp11=padarray(countp11,[0,t2-r4],0,'post');
                  dif11=countp11-count1;
                  
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);
 
                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                  dif1(:,i)=transpose(dif11);
              end
          end
         if(max_count1_dim<max_countp1_dim)
              count11=padarray(count1,[0,max_countp1_dim-max_count1_dim],0,'pre');
              [r3 r4]=size(count11);
              if(r4==r2)
                  dif11=countp1-count11;
                  
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);

                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                  dif1(:,i)=transpose(dif11);
              end
              if(r4>r2)
                  countp11=padarray(countp1,[0,r4-r2],0,'post');

                  dif11=countp11-count11;
                  
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);
                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
      
                  dif1(:,i)=transpose(dif11);
              end
               if(r4<r2)
                  count11=padarray(count11,[0,r2-r4],0,'post');
                 
                  dif11=countp1-count11;
                  %%equalization
                  
                  [h1 h2]=size(dif11);
                  [h3 h4]=size(dif1);
                 
                  if(h2>h3)
                      dif1=padarray(dif1,[h2-h3,0],0,'post');
                  end
                  if(h2<h3)
                    dif11=padarray(dif11,[0, h3-h2],0,'post');
                  end
                  
                  dif1(:,i)=transpose(dif11);
               end
         end
    end

end


               
    

[z z1]=size(dif1);
dif1=abs(dif1);
%considering max value of dif1 as 100 for a given iteration i.e threshold=100
 
for i=1:m1
     if(k1(i)>0)
         for j=1:z
             if(dif1(j,i)>10000)
                 dif1(j,i)=10000;
             end
         end
     end
end

%summation of all the values for given q3 to find the errror
difsum1=sum(dif1);
if(difsum1(1)>0)
    min11=difsum1(1);
elseif(difsum1(2)>0)
    min11=difsum1(2);
else
    min11=difsum1(3);
end

[y1 y2]=size(difsum1);
%assuming the minimum difsum1 to belong to actual q1

lp1=1;
for b1=1:y2
         if(difsum1(b1)>0)
             if (difsum1(b1)<=min11)
                 lp1=b1;
                 min11=difsum1(b1);
             end
         end
 end
 q_final=lp1;