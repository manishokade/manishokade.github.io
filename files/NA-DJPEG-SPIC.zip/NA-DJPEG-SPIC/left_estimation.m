function [c2,c12]=left_estimation(Ts1,c,x,hist_filtered,p4,n1);
[l1 l2]=size(hist_filtered);
mn1=length(n1);
%% SYNTHETIC MATRIX FORMATION
%
m1=min(500,l1/3);
for i=1:mn1
    for j=1:m1
    k(i,j)=round((-n1(i)*j)/Ts1(c,x));
    end
end
m=min(p4);
k7=k;
for j=1:m1
    if (k(1,j)<=m)
        k=k(:,1:j-1);
        break;
    end
end
[a1 m1]=size(k);

for i=2:mn1
    for j=1:m1
        if(k(i,j)<min(p4))
            k(i,j:m1)=0;
            break;
        end
    end
end
A1_k=k;
%% RESIDUAL NOISE AND BAE FILTERING, HISTOGRAM COMPARISON
for i=1:length(n1)
    h=hist_filtered(:,i);
    kp=A1_k(i,:);
    
    [c12(i) c2(i) c211(i)]=filter_br1(h',p4,Ts1,c,x,n1,mn1,kp);
end

