 %% ========================== Estimation of first quantization matrix of given NON-ALIGNED double compressed image: main_na_q1_estimation.m ========================== %
%
% Description          :   Non-aligned double compressed JPEG image is formed by using uncompressed image. The first quantization matrix is 
%                           estimated by calculating the misalignedment parameter by using method by Bianchi an Piva. This is followed by restoration of 
%                           aligned boundary w.r.t. first JPEG block boundary by performing third JPEG compression. The artifact are filtered from the 
%                           obtained DCT histogram. Block artifact induced errors on the DCT histogram are encountered via a novel DCT histogram
%                            filtering strategy. In addition, the residual noise is countered utilizing the local rank transform.
%                           The altered histograms are compared with a synthetically created ideal second quantization matrix to estimate the degree of 
%                           similarity between the two cases. Utilizing the
%                           maximum degree of similarity, the selection of ?rst quantization value is performed.

%Input parameters     :    filename = '.\':  Location from where the image is to be read
%                                      
%                           Q1 :  Quality factor between 50-100 for first quantization
%                           Q2 :  Quality factor between 50-100 for second quantization
%                           th :  threshold for LRT
%                           shiftx: misalignment or cropping in x-axis
%                           shifty: misalignment or cropping in the y-axis
%
% Output parameters    :    qtable(estimated first quantization matrix)
%                           
% Subroutine  called   :    dct_tst.m; mainhis1_qnt.m;mainhis1_idct.m;
% mainhis2_dct.m; mainhis2_qnt.m; mainhis2_deqnt.m;
% hist_comp.m;right_estimation.m; left_estimation.m; split_rem.m;
% filter_br.m; filter_br1.m; 
%                           
%                            
%
% Reference            :    1)F. Galvan, G. Puglisi, A. R. Bruna, and S. Battiato, �First quantization matrix estimation
%                               from double compressed JPEG images,� IEEE Transactions on Information Forensics and Security, 
%                               vol. 9, no. 8, pp. 1299�1310, Aug 2014. 
%                           2)J. Lukas and J. Fridrich, �Estimation of primary quantization matrix in double compressed JPEG images,� 
%                               in Digit. Forensic Res. Workshop (DFRWS), 2003, pp. 5�8.           
%
%
%
% Author of the code   :    Nandita Dalmia
% 
% ---------------------------------------------------------------------------------------------------------------------------------- %
%           ECE Department, NIT ROURKELA, India.
% ---------------------------------------------------------------------------------------------------------------------------------- %
% 
 

clc
 clear all
 close all
% 
% %enter the value of quality factor
 Q1=input('enter value of Quality factor for first compresssion :');
 Q2=input('enter value of Quality factor for second compresssion:');
 qtable=zeros([8,8]);

 
 shiftx=input('shiftx');
 shifty=input('shifty');
% % %enter the filename
 filename='ucid00218.tif';
 im1=imread(filename);
 im2=rgb2ycbcr(im1);
 im=im2(:,:,1);
 %// Define base quantization matrix
Tb=[16  11  10  16  24   40   51   61;
    12  12  14  19  26   58   60   55;
    14  13  16  24  40   57   69   56;
    14  17  22  29  51   87   80   62;
    18  22  37  56  68   109  103  77;
    24  35  55  64  81   104  113  92;
    49  64  78  87  103  121  120  101;
    72  92  95  98  112  100  103  99];


%// Determine S and first quantization matrix(Ts)
if (Q1 < 50)
    S = 5000/Q1;
    Ts = floor((S*Tb + 50) / 100);

elseif(Q1==100)
    Ts=ones(8,8);

else
    S = 200 - 2*Q1;
    Ts = floor((S*Tb + 50) / 100);

end
%%%%%%%%%%%%%
%// Determine S1 and second quantization matrix(Ts1)
if (Q2 < 50)
    S1 = 5000/Q2;
    Ts1 = floor((S1*Tb + 50) / 100);

elseif(Q2==100)
    Ts1=ones(8,8);

else
    S1 = 200 - 2*Q2;
    Ts1 = floor((S1*Tb + 50) / 100);
end

%% DCT of the given image
dct_jpeg1= bdct(im,8);

% %QUANTIZATION JPEG-I
quantization_jpeg1= quantize(dct_jpeg1,Ts);
% DEQUANTIZATION JPEG-I
dequantization_jpeg1=dequantize(quantization_jpeg1,Ts);
jpeg_1final=uint8(ibdct(dequantization_jpeg1,8));
% 

[a b]=size(jpeg_1final);

quant_1=jpeg_1final(shiftx:a,shifty:b);

%(4:a-4,4:b-4) %% DCT-II
 dct_jpeg2= bdct(quant_1);
% %%QUANTIZATION JPEG-II
quantization_jpeg2=quantize(dct_jpeg2,Ts1);
dp=quantization_jpeg2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%DJPEG IMAGE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555
 

dp_dequantize=dequantize(dp,Ts1);   
dp=ibdct(dp_dequantize);
dpp1=dp;
%[shift12,shift11]=main_misalignment(uint8(dp)); %SHIFT ESTIMATION
shift12=shifty;
shift11=shiftx;
disp(shift11);
disp(shift12);
[a b]=size(dp);
%CROP BASED ON MISALIGNMENT
jpeg_2final=dp(10-shift11:a,10-shift12:b);
disp(10-shift11);
disp(10-shift12);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for c=1:5
    for x=1:6-c
        
%% DCT-II
dct_jpeg2= mainhis1_dct(jpeg_2final);

%%QUANTIZATION JPEG-II
[quantization_jpeg2, p4]= mainhis2_qnt(c,x,dct_jpeg2,Ts1);
pl14=p4;
%%DEQUANTIZATION JPEG-II
[dequantization_jpeg2,p1]= mainhis2_deqnt(c,x,quantization_jpeg2,Ts1);
pl11=p1;
% %%IDCT jpeg2
 dp=mainhis1_idct(dequantization_jpeg2);
 [a b]=size(dp);
%% HISTOGRAM COUNTS
a=0;
m11=floor(min(min(p1)));
m21=ceil(max(max(p1)));
m0=m21-m11;
[a1, b1]=size(p1);

 
count=zeros(m0+1,1);

for k2=(m11):(m21)
    for i=1:a1
        for j=1:b1
            if(k2==round(p1(i,j)))          
                    count(k2-m11+1)=count(k2-m11+1)+1;
            end
        end
    end
end
p5=count;
t=m11:m21;


%%histogram for dequantization JPEG-II at specific position
m111=floor(min(min(p4)));
m211=ceil(max(max(p4)));
m01=(m211)-(m111);
[a11, b11]=size(p4);
countp1=zeros(m01+1,1);

for k21=(m111):(m211)
     for i=1:a11
        for j=1:b11
            if(k21==round(p4(i,j)))
                    countp1(k21-m111+1)=countp1(k21-m111+1)+1;
            end
        end
    end
end


tp1=m111:m211;

k1=Ts1(c,x)+1:25;
 %dct histogram selection to select the final value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DCT HISTOGRAM COMPARISON BY FORMATION OF SYNTHETIC DOUBLE COMPRESSED IMAGE
%AND IMAGE FORMED IN THE PREVIOUS STAGE
[p8,a1,difsum1,dif1,q_final]=hist_comp(k1,dpp1,Ts1,c,x,p4,transpose(countp1));
m=1;

%% THRESHOLDING 
dif_sort=sort(difsum1);
if(length(dif_sort)<=7)
    mn1=length(dif_sort);
else
    mn1=7;
end
n1=zeros([1,7]);
difsum2=zeros([1,7]);
for j=1:mn1
    for i=m:length(difsum1)
        if(difsum1(i)<=dif_sort(mn1) && difsum1(i)<=3.*dif_sort(1))
            difsum2(j)=difsum1(i);
            n1(j)=i+Ts1(c,x);
            m=i+1;
            break;
        end
    end
end



mn1=length(n1);
[a b]=max(countp1);
q2=Ts1(c,x);
hist_filtered=[count,count,count,count,count,count,count,count];

%%BAE FILTERING, RESIDUAL NOISE REMOVAL AND SELECTION STRATEGY 
%RIGHT HALF
c1=[];
c11=[];
[c1,c11]=right_estimation(Ts1,c,x,hist_filtered,p4,n1);
%LEFT HALF
c2=[];
c12=[];
[c2,c12]=left_estimation(Ts1,c,x,hist_filtered,p4,n1);
% MAXIMUM SIMILARITY OF THE TWO HALVES
[v11 l11]=max(c1);
[v12 l12]=max(c2);
j=1;
l1=[];
for i=l11:7
    if(v11==c1(i))
        l1(j)=i;
        j=j+1;
    end
end
j=1;
l2=[];
for i=l12:7
    if(v12==c2(i))
        l2(j)=i;
        j=j+1;
    end
end
%% SIMILARITY PERCENTAGE COMPARISON
similarity_new1=[];
for i=1:length(l1)
similarity_new1(i)=c11(l1(i));
end

[similarity_max1 loc_max1]=max(similarity_new1);
loc_max_right=l1(loc_max1);
similarity_new2=[];
for i=1:length(l2)
similarity_new2(i)=c12(l2(i));
end
%% ESTIMATED q1 VALUE
[value1 n111]=max(c11);
[value2 n112]=max(c12);
if(n111==n112)
    qtable1(c,x)=n1(n111);
else
    if(value1>value2)
        qtable1(c,x)=n1(n111);
    else
        qtable1(c,x)=n1(n112);
    end
end

qtable(c,x)=qtable1(c,x);
    end
end
disp(['The 15 coefficients of the estimated primary(first) quantization for quality factor ' num2str(Q1) ' in zig-zag order are displayed below' ]);
disp(qtable1)

disp(['The primary(first) quantization for quality factor ' num2str(Q1) ' from standard JPEG table is' ]);
disp(jpeg_qtable(Q1));

performance_graph_zeroMisallignment

