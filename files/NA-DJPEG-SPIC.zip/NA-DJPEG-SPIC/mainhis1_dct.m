 function dct_jpeg1= mainhis1_dct(im_gray)



%%extract 8*8 block
im_sub1=im_gray-128;
dct_jpeg1=bdct(im_sub1,8);
[a b]=size(dct_jpeg1);
% 
% for k1=1:8
%     for k2=1:8 
%         for i=0:(a/8)-1
%             for j=0:(b/8)-1
%                 a1(i+1,j+1,k1,k2)=dct_jpeg1(8*i+k1,8*j+k2);
%             end
%         end
%     end
% end
% disp(a1);
% disp(a)
% disp(b)
% p=reshape(a1(:,:,c,x),1,a*b/64);
% figure
% histo(p);
% title('histogram of  DCT1 component at a specific position in 8*8 image block');
% figure
% histo(dct_jpeg1);
% title('DCT histogram');