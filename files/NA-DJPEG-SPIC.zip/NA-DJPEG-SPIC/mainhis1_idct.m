function jpeg_1final=mainhis1_idct(dequantization_jpeg1)

%%IDCT JPEG-I

%idct and then rounding off
idct_jpeg1=round(ibdct(dequantization_jpeg1));

%shifting the coefficient by +128 and finally bringing in the range of 0 to 255

jpeg_1final=idct_jpeg1+128;
 
[a b]=size(jpeg_1final);
%lm=jpeg_1final;
for i=1:a
     for j=1:b
         if(jpeg_1final(i,j)<=0)
             jpeg_1final(i,j)=0;

         else if(jpeg_1final(i,j)>=255)
                 jpeg_1final(i,j)=255;
 
             end
         end
     end
end