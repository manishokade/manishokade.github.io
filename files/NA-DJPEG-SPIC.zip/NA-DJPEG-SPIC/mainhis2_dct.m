 function dct_jpeg2 = mainhis2_dct(jpeg_1final)


im_sub1=jpeg_1final-128;
%% second JPEG compression
 [a b]=size(im_sub1);
if(mod(a,8)~=0)
    im_sub1=padarray(im_sub1,[8,0],0,'post');
end
if(mod(b,8)~=0)
    im_sub1=padarray(im_sub1,[0,8],0,'post');
end
%shifting the coefficient by 128 to get in range of -128 to 127


%dct
dct_jpeg2=bdct(im_sub1,8);

% [a b]=size(dct_jpeg2);
% 
% % extracting specific coefficient values of the 8*8 blocks
% for k1=1:8
%     for k2=1:8 
%         for i=0:(a/8)-1
%             for j=0:(b/8)-1
%                 a2(i+1,j+1,k1,k2)=dct_jpeg2(8*i+k1,8*j+k2);
%             end
%         end
%     end
% end
% km1=a*b/64;
% p2=reshape(a2(:,:,c,x),1,km1);

% figure
% histo(p2);
% title('histogram of second JPEG DCT at specific location');
% xlabel('intensity value');
% ylabel('number of elements');
% 
% figure
% histo(dct_jpeg2);
% title('histogram of second JPEG DCT');
% xlabel('intensity value');
% ylabel('number of elements');