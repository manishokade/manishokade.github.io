 function [dequantization_jpeg2,p4]= mainhis2_deqnt(c,x,quantization_jpeg2,Ts1)



%% DEQUANTIZATION JPEG-II

%dequantize
dequantization_jpeg2=dequantize(quantization_jpeg2,Ts1);
[a b]=size(dequantization_jpeg2);

if(a~=0 && b~=0)
    
k=1;
%selecting values of specific location of given 8*8 windows
for k1=c:8:a
    for k2=x:8:b 
        p4(k)=dequantization_jpeg2(k1,k2);
        k=k+1;
    end
end
end
% 
% figure
% histo(p1);
% title('Second JPEG dequantization','FontSize',18);
% xlabel('intensity value','FontSize',18);
% ylabel('number of elements','FontSize',18);