 function [quantization_jpeg2, p4]= mainhis2_qnt(c,x,dct_jpeg2,Ts1)

%quantize
quantization_jpeg2=quantize(dct_jpeg2,Ts1);
[a,b]=size(quantization_jpeg2);

% figure;
% histo(quantization_jpeg2);
% title('quantize jpeg2')
if(a~=0 && b~=0)
    
k=1;
%selecting values of specific location of given 8*8 windows
for k1=c:8:a
    for k2=x:8:b 
        p4(k)=quantization_jpeg2(k1,k2);
        k=k+1;
    end
end
end
% figure
% histo(p4);
% title('Second JPEG quantization');
% xlabel('coefficient value');
% ylabel('number of elements');