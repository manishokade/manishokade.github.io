function value=parameter_estimation(f)
f1=f;
f=padarray(f,[1,1]);
[a b]=size(f);
%%BOUNDARY LOCALIZATION
for i=2:a-1
for j=2:b-1
if(f(i+1,j+1)~=0 && mod(j,8)~=0 && mod(i,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
if(f(i+1,j-1)~=0 && mod(j-2,8)~=0 && mod(i,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
if(f(i-1,j+1)~=0 && mod(j,8)~=0 && mod(i-2,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
if(f(i-1,j-1)~=0 && mod(j-2,8)~=0 && mod(i-2,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
if(f(i,j-1)~=0 && mod(j-2,8)~=0 && mod(i-1,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
if(f(i,j+1)~=0 && mod(j,8)~=0 && mod(i-1,8)~=0 && mod(j-1,8)~=0  && mod(i-1,8)~=0 )
f1(i-1,j-1)=0;
end
end

end

for i=1:a-2
    for j=1:b-2
        if(f1(i,j)~=0)
            f1(i,j)=1;
        end
    end
end
%% 1D BOUNDARY STRENGTH
f2=sum(f1);
[a b]=size(f2);
f3(1)=sum(f2(1:8:b));
f3(2)=sum(f2(2:8:b));
f3(3)=sum(f2(3:8:b));
f3(4)=sum(f2(4:8:b));
f3(5)=sum(f2(5:8:b));
f3(6)=sum(f2(6:8:b));
f3(7)=sum(f2(7:8:b));
f3(8)=sum(f2(8:8:b));
f4=f3(1:7);
th=50;
for i=1:7
    [m1(i) m2(i)]=max(f4);
    f4(m2(i))=0;
end
% THRESHOLDING TO ESTIMATE THE MISALIGNMENT PARAMETER
th=50;
val=m2(3);
if(m2(1)~=1 && m2(1)~=7)
    val=m2(1);
elseif(m2(2)~=1 && m2(2)~=7)
    val=m2(2);
elseif(m1(1)-m1(2)>=th)
    val=m2(1);
else
    val=m2(3);
end
value=9-val;