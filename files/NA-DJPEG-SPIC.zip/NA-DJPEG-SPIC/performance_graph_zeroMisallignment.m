

p = 1;
for Q11 = 50:10:90
    for Q12 = 60:10:100
        if(Q12>Q11)
            res_Q1Q2(p,:) = [Q11,Q12];
            p = p+1;
        end
    end
end
for exp =1:15
% %enter the value of quality factor
% Q1=input('enter value of Quality factor for first compresssion :');
% Q2=input('enter value of Quality factor for second compresssion:');
 qtable=zeros([8,8]);
 Q1 = res_Q1Q2(exp,1);
 Q2 = res_Q1Q2(exp,2);
  %shiftx=input('shiftx');
 %shifty=input('shifty');
  shiftx= round(2+6*rand(1));
  shifty = round(2+6*rand(1));
 
% % %enter the filename
 %filename='ucid00219.tif';
 im1=imread(filename);
 im2=rgb2ycbcr(im1);
 im=im2(:,:,1);
 %// Define base quantization matrix
Tb=[16  11  10  16  24   40   51   61;
    12  12  14  19  26   58   60   55;
    14  13  16  24  40   57   69   56;
    14  17  22  29  51   87   80   62;
    18  22  37  56  68   109  103  77;
    24  35  55  64  81   104  113  92;
    49  64  78  87  103  121  120  101;
    72  92  95  98  112  100  103  99];


%// Determine S and first quantization matrix(Ts)
if (Q1 < 50)
    S = 5000/Q1;
    Ts = floor((S*Tb + 50) / 100);

elseif(Q1==100)
    Ts=ones(8,8);

else
    S = 200 - 2*Q1;
    Ts = floor((S*Tb + 50) / 100);

end
%%%%%%%%%%%%%
%// Determine S1 and second quantization matrix(Ts1)
if (Q2 < 50)
    S1 = 5000/Q2;
    Ts1 = floor((S1*Tb + 50) / 100);

elseif(Q2==100)
    Ts1=ones(8,8);

else
    S1 = 200 - 2*Q2;
    Ts1 = floor((S1*Tb + 50) / 100);
end

%% DCT of the given image
dct_jpeg1= bdct(im,8);

% %QUANTIZATION JPEG-I
quantization_jpeg1= quantize(dct_jpeg1,Ts);
% DEQUANTIZATION JPEG-I
dequantization_jpeg1=dequantize(quantization_jpeg1,Ts);
jpeg_1final=uint8(ibdct(dequantization_jpeg1,8));
% 

[a b]=size(jpeg_1final);

quant_1=jpeg_1final(shiftx:a,shifty:b);

%(4:a-4,4:b-4) %% DCT-II
 dct_jpeg2= bdct(quant_1);
% %%QUANTIZATION JPEG-II
quantization_jpeg2=quantize(dct_jpeg2,Ts1);
dp=quantization_jpeg2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%DJPEG IMAGE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555
 

dp_dequantize=dequantize(dp,Ts1);   
dp=ibdct(dp_dequantize);
dpp1=dp;
% [a,b]=size(dpp1);
% im_final1=dpp1;
% im_final1=padarray(im_final1,[1,1],'post');
% im_final1=double(im_final1);
% %% LPD:
% for x=1:a
%     for y=1:b
%         f(x,y)=im_final1(x,y)+im_final1(x+1,y+1)-im_final1(x+1,y)-im_final1(x,y+1);
%     end
% end
% %% MISALIGNMENT PARAMETER ESTIMATION
% 
% c=parameter_estimation(f');
% disp(c)
% r=parameter_estimation(f);
% disp(r)

%[shift12,shift11]=main_misalignment(uint8(dp)); %SHIFT ESTIMATION
 %[shift11,shift12]=misallign(shiftx,shifty); %SHIFT ESTIMATION
shift12=shifty;
shift11=shiftx;
%disp(shift11);
%disp(shift12);
[a b]=size(dp);
%CROP BASED ON MISALIGNMENT
jpeg_2final=dp(10-shift11:a,10-shift12:b);%doubt: why 10 ?
%disp(10-shift11);
%disp(10-shift12);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for c=1:5
    for x=1:6-c
        
%% DCT-II
dct_jpeg2= mainhis1_dct(jpeg_2final);

%%QUANTIZATION JPEG-II
[quantization_jpeg2, p4]= mainhis2_qnt(c,x,dct_jpeg2,Ts1);
pl14=p4;
%%DEQUANTIZATION JPEG-II
[dequantization_jpeg2,p1]= mainhis2_deqnt(c,x,quantization_jpeg2,Ts1);
pl11=p1;
% %%IDCT jpeg2
 dp=mainhis1_idct(dequantization_jpeg2);
 [a b]=size(dp);
%% HISTOGRAM COUNTS
a=0;
m11=floor(min(min(p1)));
m21=ceil(max(max(p1)));
m0=m21-m11;
[a1, b1]=size(p1); 
count=zeros(m0+1,1);
for k2=(m11):(m21)
    for i=1:a1
        for j=1:b1
            if(k2==round(p1(i,j)))          
                    count(k2-m11+1)=count(k2-m11+1)+1;
            end
        end
    end
end
p5=count;
t=m11:m21;


%%histogram for dequantization JPEG-II at specific position
m111=floor(min(min(p4)));
m211=ceil(max(max(p4)));
m01=(m211)-(m111);
[a11, b11]=size(p4);
countp1=zeros(m01+1,1);

for k21=(m111):(m211)
     for i=1:a11
        for j=1:b11
            if(k21==round(p4(i,j)))
                    countp1(k21-m111+1)=countp1(k21-m111+1)+1;
            end
        end
    end
end


tp1=m111:m211;

k1=Ts1(c,x)+1:25;
 %dct histogram selection to select the final value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DCT HISTOGRAM COMPARISON BY FORMATION OF SYNTHETIC DOUBLE COMPRESSED IMAGE
%AND IMAGE FORMED IN THE PREVIOUS STAGE
[p8,a1,difsum1,dif1,q_final]=hist_comp(k1,dpp1,Ts1,c,x,p4,transpose(countp1));
m=1;

%% THRESHOLDING 
dif_sort=sort(difsum1);
if(length(dif_sort)<=7)
    mn1=length(dif_sort);
else
    mn1=7;
end
n1=zeros([1,7]);
difsum2=zeros([1,7]);
for j=1:mn1
    for i=m:length(difsum1)
        if(difsum1(i)<=dif_sort(mn1) && difsum1(i)<=3.*dif_sort(1))
            difsum2(j)=difsum1(i);
            n1(j)=i+Ts1(c,x);
            m=i+1;
            break;
        end
    end
end



mn1=length(n1);
[a b]=max(countp1);
q2=Ts1(c,x);
hist_filtered=[count,count,count,count,count,count,count,count];

%%BAE FILTERING, RESIDUAL NOISE REMOVAL AND SELECTION STRATEGY 
%RIGHT HALF
c1=[];
c11=[];
[c1,c11]=right_estimation(Ts1,c,x,hist_filtered,p4,n1);
%LEFT HALF
c2=[];
c12=[];
[c2,c12]=left_estimation(Ts1,c,x,hist_filtered,p4,n1);
% MAXIMUM SIMILARITY OF THE TWO HALVES
[v11 l11]=max(c1);
[v12 l12]=max(c2);
j=1;
l1=[];
for i=l11:7
    if(v11==c1(i))
        l1(j)=i;
        j=j+1;
    end
end
j=1;
l2=[];
for i=l12:7
    if(v12==c2(i))
        l2(j)=i;
        j=j+1;
    end
end
%% SIMILARITY PERCENTAGE COMPARISON
similarity_new1=[];
for i=1:length(l1)
similarity_new1(i)=c11(l1(i));
end

[similarity_max1 loc_max1]=max(similarity_new1);
loc_max_right=l1(loc_max1);
similarity_new2=[];
for i=1:length(l2)
similarity_new2(i)=c12(l2(i));
end
%% ESTIMATED q1 VALUE
[value1 n111]=max(c11);
[value2 n112]=max(c12);
if(n111==n112)
    qtable1(c,x)=n1(n111);
else
    if(value1>value2)
        qtable1(c,x)=n1(n111);
    else
        qtable1(c,x)=n1(n112);
    end
end

qtable(c,x)=qtable1(c,x);
    end
end
%disp(qtable1);
error(:,:,exp) = Ts(1:5,1:5)-qtable1;
end
err_tot = zeros(5,5);
for u = 1:15
 err_tot = err_tot+abs(error(:,:,u));
 % abs(error(:,:,u))
 % err_tot
end
err_tot = err_tot/15;
band_err(1:15) = [err_tot(1,1), err_tot(1,2), err_tot(2,1), err_tot(3,1), err_tot(2,2), err_tot(1,3),err_tot(1,4),err_tot(2,3),err_tot(3,2),err_tot(4,1),err_tot(5,1),err_tot(4,2),err_tot(3,3),err_tot(2,4),err_tot(1,5)];
band_err = band_err./[Ts(1,1), Ts(1,2), Ts(2,1), Ts(3,1),Ts(2,2), Ts(1,3),Ts(1,4),Ts(2,3),Ts(3,2),Ts(4,1),Ts(5,1),Ts(4,2),Ts(3,3),Ts(2,4),Ts(1,5)];
figure
plot(band_err(1:length(band_err))*100);
xlim([1,15]);
xlabel('DCT coefficients');
ylabel('Percentage Error');