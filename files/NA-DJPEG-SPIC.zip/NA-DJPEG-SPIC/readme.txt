The Main file for the proposed work is 

main_na_q1_estimation.m

This file inturn calls several sub-routines as listed in the intial part of the file "main_na_q1_estimation.m". Please note that we have estimated 15 DCT cefficients in zig-zag order. This can also be modified to estimate all 64 coefficients of the first quantization matrix.

