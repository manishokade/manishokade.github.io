function [c1,c11]=right_estimation(Ts1,c,x,hist_filtered,p4,n1)


[l1 l2]=size(hist_filtered);
mn1=length(n1);
q2=Ts1(c,x);
i=0;
for j=1:q2:l1
    i=i+1;  
    h_filt(i,:)=hist_filtered(j,:);
end 
hist_filtered=h_filt;
% SYNTHETIC HISTOGRAM MATRIX FORMATION
m1=min(500,l1/3);
for i=1:mn1
    for j=1:m1
    k(i,j)=round((n1(i)*j)/Ts1(c,x));
    end
end
m=max(p4);
k7=k;

for j=1:m1
    if (k(1,j)>=m)
        k=k(:,1:j-1);
        break;
    end
end
[a1 m1]=size(k);

for i=2:mn1
    for j=1:m1
        if(k(i,j)>max(p4))
            k(i,j:m1)=0;
            break;
        end
    end
end
A_k=k;
%% BAE FILTERING, RESIDUAL NOISE FILTERING AND HISTOGRAM COMPARISON
for i=1:length(n1)
    h=hist_filtered(:,i);
    kp=k(i,:);
    [c11(i) c1(i)]=filter_br(h',p4,Ts1,c,x,n1,mn1,kp);
end
