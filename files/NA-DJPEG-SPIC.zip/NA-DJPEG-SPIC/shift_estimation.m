function [k1,k2]=shift_estimation(Ts1,dp);
 th1 = 4;
% % threshold on min-entropy of DIPM
 th2 = 2.5;
 k=1;
 [H1,H2] = minHNA(dp,Ts1);
    [k1,k2,Q,IPM,DIPM] = detectNA(dp,Ts1,th1,th2,false);
