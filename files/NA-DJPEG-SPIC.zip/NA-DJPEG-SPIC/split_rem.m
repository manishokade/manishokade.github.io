function  h=split_rem(p1,n1,q2,count,Ts1,c,x,mn1)

%%SPLIT NOISE REMOVAL

m11=floor(min(p1));
m21=ceil(max(p1));

[a1, b1]=size(p1);


q2=Ts1(c,x);
m211=floor(m21/q2);

%different loops for positive and negative side of the histogram
for i=1:length(n1)
    q1=n1(i);
    h(:,i)=count;    
    for m=1:floor(m21/q2)
         for n=1:(m211-2) 
             if((m*q1==(n*q2+(n+1)*q2)/2))
                 %|| (m*q1==ceil((n*q2+(n+1)*q2)/2)) || (m*q1==floor((n*q2+(n+1)*q2)/2)))     %%mq1=(nq2+(n+1)q2)/2
                 h(-m11+(n+1)+1,i)=h(-m11+n+1,i)+h(-m11+(n+1)+1,i);
                h(-m11+n+1,i)=0;
            
              end
         end
    end 
end

for i=1:length(n1)
    q1=n1(i);
m221=(-m11/q2);

    for n=1:floor(m21/q2)
        for m=1:(m221-2)
           if((m*q1==(n*q2+(n+1)*q2)/2))     %%mq1=(nq2+(n+1)q2)/2
%      || (m*q1==ceil((n*q2+(n+1)*q2)/2)) || (m*q1==floor((n*q2+(n+1)*q2)/2))
                h(-m11-(m+1)+1,i)=h(-m11-m+1,i)+h(-m11-(m+1)+1,i);
                h(-m11-m+1,i)=0;
            
           end
        end
    end
end

 
%  disp(q2);
%  [a b]=size(h);
 %b=m11:m21;
%  figure;
%  stem(b,h(:,7));
%  title('error correction');
b=m11:m21;
% figure
% stem(b,h(:,));
% title('histogram after split noise removal --> error correction');
% xlabel('intensity value');
% ylabel('number of elements'); 




