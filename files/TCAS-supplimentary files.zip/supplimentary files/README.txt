# Reproducibility README

This README describes the tools, technology libraries, constraints(given in supplementary files), and step-by-step procedure required to reproduce **Tables II–V** reported in the paper, covering standard-cell synthesis results and FPGA implementation results for masked AND2 gates, Midori S-boxes, and SPN units.

---

## 1. Tool Versions

### ASIC Flow

* **Logic Synthesis & Analysis:** Synopsys Design Compiler **T-2022.03-SP5**
* **Power Analysis:** Synopsys Design Compiler (post-synthesis, switching activity–based)

### FPGA Flow

* **FPGA Tool:** Xilinx Vivado **2017.4**
* **Power Estimation:** Vivado Power Analyzer using SAIF activity files

---

## 2. Technology Libraries

The following standard-cell libraries(.db files) were used for ASIC synthesis:

* **UMC 180 nm** (UMC180)
* **SAED 90 nm**
* **SAED 32 nm**
* **Nangate Open Cell Library (45 nm)**

For each technology, synthesis and timing analysis were performed under three PVT corners:

* **FF (Fast–Fast)**
* **TT (Typical–Typical)**
* **SS (Slow–Slow)**

---

## 3. Device and Platform Details

### FPGA Platform (Tables V and VI)

* **Board:** Nexys4 DDR
* **FPGA Device:** Xilinx Artix-7 (XC7A100T)
* **Architecture:** 64-bit Midori-64 SPN with 16 parallel S-boxes

---

## 4. Clock and Voltage Constraints

### ASIC Synthesis

* **Clock period:** Set according to target critical path delay (CPD) for each technology
* **Supply voltage:** Nominal library voltage (as defined in the respective PDK)
* **Timing constraint:** Single-clock synchronous design with zero I/O delay assumption

### FPGA Implementation

* **Clock frequency:** Derived from post-implementation timing (Fmax)
** **Supply voltage:** Default Artix-7 core voltage (Vivado tool default)

---

## 5. Reproducing Table III & IV (Masked AND2 Gates – ASIC)(synthesis.tcl file in supplementary files folder)

1. Launch Synopsys Design Compiler:

   ```
   dc_shell
   ```
2. Read technology library (UMC 180 nm / SAED / Nangate):

   ```
   set target_library <tech_lib>.db
   set link_library "* <tech_lib>.db"
   ```
3. Read RTL for AND2 variants (TAND2, MAND2, GLFREMAND2):

   ```
   read_verilog mand2.v
   ```
4. Apply clock constraint:

   ```
   create_clock -name clk -period <Tclk>
   ```
5. Compile and optimize:

   ```
   compile_ultra
   ```
6. Report metrics:

   ```
   report_area
   report_timing
   report_power
   ```
7. Repeat for FF, TT, and SS corners and record **best, worst, and mean** values.

---

## 6. Reproducing Table V (Midori S-box – ASIC, SAED 90 nm)

1. Integrate the S-box RTL (Unmasked, TAND2, MAND2 variants).
2. Use SAED 90 nm library with identical clock constraints for all designs.
3. Perform synthesis and power analysis as in Section 5.
4. Extract:

   * Area (GE)
   * Critical Path Delay (CPD)
   * Total Path Delay (TPD)
   * Dynamic Power


---

## 7. Reproducing Table V (Midori-64 Architecture – FPGA)

1. Open Vivado 2017.4 and create a new RTL project.
2. Select **Nexys4 DDR (XC7A100T)** as the target board.
3. Add RTL files for 16×4 Midori-64 architecture variants.
4. Run:

   * Synthesis
   * Implementation
5. Record:

   * LUTs and slices
   * Post-implementation delay
   * Fmax and throughput

---

## 8. Reproducing Table VI (SPN Unit – FPGA Power & Energy)

1. Perform post-implementation functional simulation.
2. Generate SAIF file from simulation activity.
3. Import SAIF into Vivado Power Analyzer.
4. Record:

   * Total power (W)
   * Critical delay (ns)
   * Fmax (MHz)
   * Energy (nJ)

Energy values are computed as:


Energy = Power × delay Period

NB: For further clarification or access to RTL scripts and constraint files, please refer to the supplementary files folder or contact the authors.
