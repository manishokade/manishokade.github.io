function [ shift_image ] = crop_img( org_img)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
    [row,col,dep] = size(org_img);
    cntr_pxl = (1/2)*[row,col];
    %crop_size = area_crop.*[row,col];
    crop_size = [1024,1024];
    st_row = cntr_pxl(1)-(crop_size(1)/2)+1;
    st_col = cntr_pxl(2)-(crop_size(2)/2)+1;
    shift_image = org_img(st_row:st_row+crop_size(1)-1, st_col:st_col+crop_size(2)-1,:);

end

