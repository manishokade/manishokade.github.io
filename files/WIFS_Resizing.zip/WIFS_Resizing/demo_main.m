 %% ========================== Exposing Image Resizing utilizing Welch's Power Spectral Analysis for Double Compressed JPEG Images ========================== %

%Input parameters     :    filename = '.\':  Location from where the image is to be read
%                                      
%                           QF_1        :  Quality factor between 50-90 for first compression
%                           QF_2        :  Quality factor between 50-99 for second compression
%                           resize_fact :  The factor by which the image has been resized 
%
% Output parameters    :    rsz_fct_est : Estimated Resizing Factor 
                         
% Author of the code   :    Sidhant Ranjan Sahu
% Date of creation     :    
% ---------------------------------------------------------------------------------------------------------------------------------- %
%           ECE Department, NIT ROURKELA, India.
% ---------------------------------------------------------------------------------------------------------------------------------- %
% 


clear all;  close all;
addpath('.\jpegtbx_1.4');

%% image of TIF format %% 
%srcFiles = dir('.\UNcompressed\*.tif');
%img_num =15; 
%filename = strcat('.\UNcompressed\',srcFiles(img_num).name);
 filename = 'big_169.tif';
org_img_rgb = imread(filename);
org_img_Ycbcr = rgb2ycbcr(org_img_rgb);
org_img_rgb_1024 = ycbcr2rgb(crop_img(org_img_Ycbcr));
%% Tamper the image with resizing %% 
QF_1 = 70; QF_2 = 90; resize_fact =0.8;
imwrite(org_img_rgb_1024,'single_compress.jpg','Quality',QF_1); %% first JPEG compression with QF-50
first_comp_ycbcr = rgb2ycbcr(imread('single_compress.jpg'));
first_comp_Y = first_comp_ycbcr(:,:,1);
figure 
plot(PSD_plot(first_comp_Y));
title('PSD Spectra(Histogram DC band) of Single Compressed Image');
img_resized_1comp = imresize(first_comp_ycbcr,resize_fact,'bicubic');
single_com_rszd = img_resized_1comp(:,:,1);
figure
plot(PSD_plot(single_com_rszd));
title('PSD Spectra(Histogram DC band) of Single Compressed Resized image');
single_comp_resized_rgb =  ycbcr2rgb(img_resized_1comp);
imwrite(single_comp_resized_rgb,'double_compress_resized.jpg','Quality',QF_2);

%% The proposed algorithm applied to Double Compressed Resized Image  %% 
second_comp_ycbcr = rgb2ycbcr(imread('double_compress_resized.jpg'));
sec_com_Y = second_comp_ycbcr(:,:,1);
figure 
plot(PSD_plot(sec_com_Y));
title('PSD Spectra(Histogram DC band) of Doubly Compressed Resized Image')
%% Estimation of candidate Resizing Factors %% 

I = sec_com_Y;
Power_spectrum

%% Resizing image in compressed Domain %% 
org_img = first_comp_ycbcr(:,:,1);
scales = [0.6 0.7 0.8 0.9 0.95 1.05 1.1 1.2 1.3 1.4];

rsz_fct_est = rszFct_psd(I, scales);
disp(['Resizing factor estimated by Proposed method : ', num2str(rsz_fct_est)])
%disp('estimated resize factor detector');
[minH, Q, k1, k2, scale] = getJRS_priori(I, scales);
disp(['Resizing factor estimated by IPM method : ',  num2str(scale)])
