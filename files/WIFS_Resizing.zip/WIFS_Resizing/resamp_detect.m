clear all;  close all;
addpath('.\jpegtbx_1.4');
srcFiles = dir('.\UNcompressed\*.tif');
img_num =13; 
filename = strcat('.\UNcompressed\',srcFiles(img_num).name);
org_img_Ycbcr = rgb2ycbcr(imread(filename));
org_img_1024 = crop_img(org_img_Ycbcr);
UnCI_Y = org_img_1024(:,:,1);
DC_UnCI = DC_band(UnCI_Y);
i_x = 1; j_y = 1;
DC_shift_UnCI = DC_UnCI(i_x:8:end,j_y:8:end);
figure 
histogram(DC_shift_UnCI);
title('DC band histogram of UnCI image');


figure 
plot(PSD_plot(org_img_1024(:,:,1)));
title('PSD Spectra(Histogram DC band) of UnCompressed Image');


QF_1 = 70; QF_2 = 90; rsz_fct = 1.4;
imwrite(ycbcr2rgb(org_img_1024),'single_compress.jpg','Quality',QF_1); %% first JPEG compression with QF_1
SCI = rgb2ycbcr(imread('single_compress.jpg'));
SCI_Y = SCI(:,:,1);
DC_SCI = DC_band(SCI_Y);
i_x = 1; j_y = 1;
DC_shift = DC_SCI(i_x:8:end,j_y:8:end);
figure 
histogram(DC_shift);
title('DC band histogram of SCI image');
figure 
plot(PSD_plot(SCI(:,:,1)));
title('PSD Spectra(Histogram DC band) of Single Compressed Image');

%SCR = SCI;
SCR = imresize(SCI,rsz_fct,'bicubic');
SCR_Y = SCR(:,:,1);
DC_SCR = DC_band(SCR_Y);
i_x = 1; j_y = 1;
DC_shift_SCR = DC_SCR(i_x:8:end,j_y:8:end);
figure 
histogram(DC_shift_SCR);
title('DC band histogram of SCR image');
figure 
plot(PSD_plot(SCR(:,:,1)));
title('PSD Spectra(Histogram DC band) of Single Compressed Resized Image');


imwrite(ycbcr2rgb(SCR),'double_compress.jpg','Quality',QF_2); %% second compression with Quality factor QF_2
DCR = rgb2ycbcr(imread('double_compress.jpg'));
DCR_Y = DCR(:,:,1);
DC_DCR = DC_band(DCR_Y);
i_x = 1; j_y = 1;
DC_shift_DCR = DC_DCR(i_x:8:end,j_y:8:end);
figure 
histogram(DC_shift_DCR);
title('DC band histogram of DCR image');
figure 
plot(PSD_plot(DCR(:,:,1)));
title('PSD Spectra(Histogram DC band) of Double Compressed resized Image');
I = DCR_Y;

%% The correct resizing factor Estimation %%
% P = findJPeaks_sc2(I);
% P.scale = round(P.scale *100)/100;
% P_sort = sort(P.scale);
% P_unique = unique(P.scale);
% jp = 1;
% P_scl(jp) = P_unique(1);
% for ip = 2:length(P_unique)
%     if((ip)<length(P_unique) && ((P_unique(ip)-P_scl(jp))>0.03)&& P_unique(ip)~=1 )
%     P_scl(jp+1) = P_unique(ip);
%     jp = jp+1;
%     end
% end
% P_scl_final = P_scl;
% 
% rsz_fct_psd = rszFct_psd(I, P_scl_final);
% disp([' rsz_fct_psd = ', num2str(rsz_fct_psd)])
% rsz_fct_nldp = getJRS_v3(I(1:512,1:512));
% disp(['  rsz_fct_nldp = ', num2str(rsz_fct_nldp)])
